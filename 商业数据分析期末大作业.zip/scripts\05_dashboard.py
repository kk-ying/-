"""05_dashboard.py —— 交互式商业分析大屏（Pyecharts，暗色主题）

组件（≥6）：KPI 指标卡 ×6、月度销售趋势、国家销售榜、商品销售榜、
RFM 八群玫瑰图、RFM 客户价值散点、时段×星期热力图、高价值客户明细表、
月度商品下钻时间轴。
联动：① 地区筛选器（全部 / 英国 / 海外）联动 KPI、趋势图与商品榜；
      ② 时间轴按月份下钻 TOP5 商品；③ 图例开关与数据缩放。
输出：outputs/dashboard.html（自包含，内联 ECharts，断网可用）。
"""
from __future__ import annotations

import json
import re

import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Bar, HeatMap, Line, Pie, Scatter, Timeline
from pyecharts.globals import ThemeType

from common import ALL_CSV, BASE_DIR, TAB_DIR

DARK = "#0B1726"
PANEL = "#12263A"
ACCENT = "#00D1FF"
OUT = BASE_DIR / "outputs" / "dashboard.html"
ASSETS = BASE_DIR / "outputs" / "assets" / "echarts.min.js"


def load():
    df = pd.read_csv(ALL_CSV, parse_dates=["InvoiceDay"], dtype={"InvoiceNo": str})
    df = df[df["InAnalysisWindow"] == 1]
    t = {n: pd.read_csv(TAB_DIR / f"{n}.csv") for n in
         ["table02_monthly_sales", "table03_country_sales", "table04_product_sales",
          "table05_rfm_customers", "table06_rfm_segments", "table15_hour_weekday"]}
    t["df"] = df
    return t


def region_payload(df: pd.DataFrame, seg_map: pd.Series, mask=None) -> dict:
    d = df if mask is None else df[mask]
    rev = float(d["Revenue"].sum())
    orders = int(d["InvoiceNo"].nunique())
    customers = int(d["CustomerID"].nunique())
    cid = d.dropna(subset=["CustomerID"])
    rep = float((cid.groupby("CustomerID")["InvoiceNo"].nunique() > 1).mean() * 100) if len(cid) else 0
    d = d.dropna(subset=["CustomerID"]).copy()
    d["segment"] = d["CustomerID"].map(seg_map)
    vip = float(d[d["segment"].isin(["重要价值客户", "重要保持客户"])]["Revenue"].sum() / rev * 100) if rev else 0
    m = d.groupby("YearMonth").agg(revenue=("Revenue", "sum"), orders=("InvoiceNo", "nunique"))
    p = (d.groupby("Description")["Revenue"].sum().sort_values(ascending=False).head(10))
    return {
        "kpi": {
            "revenue": f"£{rev / 1e6:.2f}M",
            "orders": f"{orders:,}",
            "customers": f"{customers:,}",
            "aov": f"£{rev / orders:,.0f}" if orders else "£0",
            "repeat": f"{rep:.1f}%",
            "vip": f"{vip:.1f}%",
        },
        "monthly": {"month": m.index.tolist(), "revenue": [round(v, 2) for v in m["revenue"]],
                    "orders": m["orders"].tolist()},
        "products": {"name": [str(x)[:22] for x in p.index.tolist()],
                     "value": [round(v, 2) for v in p.values]},
    }


def build_charts(t) -> tuple[dict, str, str]:
    m = t["table02_monthly_sales"]
    c = t["table03_country_sales"]
    p = t["table04_product_sales"]
    seg = t["table06_rfm_segments"]
    cust = t["table05_rfm_customers"]
    hw = t["table15_hour_weekday"]
    df = t["df"]

    # 1 趋势：销售额柱 + 订单量折线（双轴）
    bar = (Bar(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                       width="100%", height="300px"))
           .add_xaxis(m["YearMonth"].tolist())
           .add_yaxis("销售额（£）", [round(v) for v in m["revenue"]],
                      itemstyle_opts=opts.ItemStyleOpts(
                          color="#1F7FB8", border_radius=[3, 3, 0, 0]),
                      label_opts=opts.LabelOpts(is_show=False))
           .extend_axis(yaxis=opts.AxisOpts(name="订单量", axislabel_opts=opts.LabelOpts(formatter="{value}")))
           .set_global_opts(
               title_opts=opts.TitleOpts(title="月度销售额与订单量", subtitle="2010-12 至 2011-11"),
               legend_opts=opts.LegendOpts(pos_top="3%", pos_right="4%"),
               xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=40, font_size=9)),
               yaxis_opts=opts.AxisOpts(name="销售额（£）",
                                        axislabel_opts=opts.LabelOpts(formatter="{value}")),
               tooltip_opts=opts.TooltipOpts(trigger="axis"),
               datazoom_opts=[opts.DataZoomOpts(range_start=0, range_end=100)]))
    line = (Line()
            .add_xaxis(m["YearMonth"].tolist())
            .add_yaxis("订单量", m["orders"].tolist(), yaxis_index=1,
                       color="#FFC000", label_opts=opts.LabelOpts(is_show=False),
                       linestyle_opts=opts.LineStyleOpts(width=2)))
    bar.overlap(line)

    # 2 国家榜
    cd = c.head(10).iloc[::-1]
    country_bar = (Bar(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                               width="100%", height="300px"))
                   .add_xaxis([str(x) for x in cd["Country"]])
                   .add_yaxis("销售额（£）", [round(v) for v in cd["revenue"]],
                              label_opts=opts.LabelOpts(position="right", font_size=9),
                              itemstyle_opts=opts.ItemStyleOpts(color="#2E9BC6"))
                   .reversal_axis()
                   .set_global_opts(
                       title_opts=opts.TitleOpts(title="国家销售额 TOP10"),
                       xaxis_opts=opts.AxisOpts(type_="value",
                                                axislabel_opts=opts.LabelOpts(is_show=False)),
                       yaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(font_size=9)),
                       legend_opts=opts.LegendOpts(is_show=False),
                       tooltip_opts=opts.TooltipOpts(trigger="axis")))

    # 3 商品榜
    pd10 = p.head(10).iloc[::-1]
    product_bar = (Bar(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                               width="100%", height="300px"))
                   .add_xaxis([str(x)[:20] for x in pd10["Description"]])
                   .add_yaxis("销售额（£）", [round(v) for v in pd10["revenue"]],
                              label_opts=opts.LabelOpts(position="right", font_size=9),
                              itemstyle_opts=opts.ItemStyleOpts(color="#F2A33C"))
                   .reversal_axis()
                   .set_global_opts(
                       title_opts=opts.TitleOpts(title="商品销售额 TOP10"),
                       xaxis_opts=opts.AxisOpts(type_="value",
                                                axislabel_opts=opts.LabelOpts(is_show=False)),
                       yaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(font_size=9)),
                       legend_opts=opts.LegendOpts(is_show=False),
                       tooltip_opts=opts.TooltipOpts(trigger="axis")))

    # 4 RFM 玫瑰图
    pie = (Pie(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                       width="100%", height="300px"))
           .add("", [(r["segment"], round(r["revenue"])) for _, r in seg.iterrows()],
                radius=["22%", "68%"], center=["50%", "56%"], rosetype="radius",
                label_opts=opts.LabelOpts(is_show=False))
           .set_global_opts(
               title_opts=opts.TitleOpts(title="RFM 八群销售额结构"),
               legend_opts=opts.LegendOpts(orient="vertical", pos_left="1%", pos_top="18%",
                                           item_width=8, item_height=8,
                                           textstyle_opts=opts.TextStyleOpts(font_size=9)),
               tooltip_opts=opts.TooltipOpts(trigger="item", formatter="{b}<br/>£{c} ({d}%)")))

    # 5 RFM 客户散点
    s = cust.sample(min(len(cust), 1500), random_state=42)
    scatter = (Scatter(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                               width="100%", height="300px"))
               .add_xaxis([int(v) for v in s["frequency"]])
               .add_yaxis("客户", [round(v) for v in s["monetary"]],
                          symbol_size=5, symbol="circle",
                          itemstyle_opts=opts.ItemStyleOpts(color=ACCENT, opacity=0.55),
                          label_opts=opts.LabelOpts(is_show=False))
               .set_global_opts(
                   title_opts=opts.TitleOpts(title="客户购买频次 × 消费金额"),
                   xaxis_opts=opts.AxisOpts(name="频次", type_="log",
                                            axislabel_opts=opts.LabelOpts(formatter="{value}")),
                   yaxis_opts=opts.AxisOpts(name="消费金额 £", type_="log",
                                            axislabel_opts=opts.LabelOpts(formatter="{value}")),
                   legend_opts=opts.LegendOpts(is_show=False),
                   tooltip_opts=opts.TooltipOpts(formatter="F={c}")))

    # 6 时段热力图
    days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    hours = [f"{h}时" for h in hw["Hour"]]
    hdata = []
    mx = 0
    for i, h in enumerate(hw["Hour"]):
        for j, dname in enumerate(days):
            v = float(hw.iloc[i][dname])
            mx = max(mx, v)
            hdata.append([i, j, round(v)])
    heat = (HeatMap(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                            width="100%", height="300px"))
            .add_xaxis(hours)
            .add_yaxis("销售额", days, hdata, label_opts=opts.LabelOpts(is_show=False))
            .set_global_opts(
                title_opts=opts.TitleOpts(title="下单时段 × 星期（销售额）"),
                legend_opts=opts.LegendOpts(is_show=False),
                xaxis_opts=opts.AxisOpts(splitarea_opts=opts.SplitAreaOpts(is_show=True)),
                yaxis_opts=opts.AxisOpts(splitarea_opts=opts.SplitAreaOpts(is_show=True)),
                visualmap_opts=opts.VisualMapOpts(min_=0, max_=mx, is_calculable=True,
                                                  pos_bottom="2%", pos_right="1%",
                                                  textstyle_opts=opts.TextStyleOpts(font_size=9))))

    # 7 月度下钻时间轴（每月 TOP5 商品）
    tl = Timeline(init_opts=opts.InitOpts(theme=ThemeType.DARK, bg_color="transparent",
                                          width="100%", height="320px"))
    dfc = df.dropna(subset=["Description"])
    for ym in sorted(df["YearMonth"].unique()):
        d = dfc[dfc["YearMonth"] == ym].groupby("Description")["Revenue"].sum().nlargest(5).iloc[::-1]
        b = (Bar()
             .add_xaxis([str(x)[:24] for x in d.index])
             .add_yaxis("销售额（£）", [round(v) for v in d.values],
                        label_opts=opts.LabelOpts(position="right", font_size=9),
                        itemstyle_opts=opts.ItemStyleOpts(color="#3FB6D9"))
             .reversal_axis()
             .set_global_opts(
                 title_opts=opts.TitleOpts(title=f"{ym} 商品销售额 TOP5"),
                 xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(is_show=False)),
                 yaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(font_size=9)),
                 legend_opts=opts.LegendOpts(is_show=False)))
        tl.add(b, ym)
    tl.add_schema(is_auto_play=True, play_interval=1800, is_loop_play=True,
                  width="100%", pos_bottom="0%")

    # 8 明细表（TOP10 高价值客户）
    seg_map = cust.set_index("CustomerID")["segment"]
    top = cust.nlargest(10, "monetary")[["CustomerID", "segment", "frequency", "monetary", "recency"]]
    rows = "".join(
        f"<tr><td>{int(r.CustomerID)}</td><td>{r.segment}</td><td>{int(r.frequency)}</td>"
        f"<td>£{r.monetary:,.0f}</td><td>{int(r.recency)} 天</td></tr>"
        for r in top.itertuples())

    # 地区筛选数据
    seg_map_all = cust.set_index("CustomerID")["segment"]
    payload = {
        "all": region_payload(df, seg_map_all),
        "uk": region_payload(df, seg_map_all, df["Country"] == "United Kingdom"),
        "overseas": region_payload(df, seg_map_all, df["Country"] != "United Kingdom"),
    }
    return {"trend": bar, "country": country_bar, "product": product_bar, "pie": pie,
            "scatter": scatter, "heat": heat, "timeline": tl, "table": rows,
            "payload": payload}


def fragment(html: str) -> str:
    """从 pyecharts 的完整 HTML 中抽取图表片段，并去掉重复的 CDN 脚本标签。"""
    html = re.sub(r"<script[^>]*src=[^>]*echarts\.min\.js[^>]*>\s*</script>", "", html)
    body = re.search(r"<body[^>]*>(.*?)</body>", html, re.S)
    return body.group(1) if body else html


def render(t, charts) -> None:
    payload = charts["payload"]
    ids = {k: charts[k].chart_id for k in ["trend", "country", "product", "pie", "scatter", "heat"]}
    embeds = {k: fragment(charts[k].render_embed())
              for k in ["trend", "country", "product", "pie", "scatter", "heat"]}
    tl_embed = fragment(charts["timeline"].render_embed())

    js_lib = (f"<script>{ASSETS.read_text(encoding='utf-8')}</script>" if ASSETS.exists() else
              '<script src="https://unpkg.com/echarts@5.5.1/dist/echarts.min.js"></script>')

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>Online Retail 商业分析大屏</title>
{js_lib}
<style>
* {{ box-sizing: border-box; }}
body {{
  margin: 0; padding: 18px 22px 26px; background: radial-gradient(circle at 20% 0%, #14304a 0%, {DARK} 45%, #060f1a 100%);
  color: #E6F1FF; font-family: "Microsoft YaHei", "PingFang SC", sans-serif;
}}
.header {{ display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:14px;
  border-bottom:1px solid rgba(0,209,255,.35); padding-bottom:10px; }}
.header h1 {{ margin:0; font-size:23px; letter-spacing:1px; }}
.header h1 span {{ color:{ACCENT}; }}
.header .sub {{ font-size:12px; color:#8FA8C0; }}
.filter {{ display:flex; gap:10px; align-items:center; }}
.filter select {{ background:#13293D; color:#E6F1FF; border:1px solid {ACCENT}; border-radius:6px;
  padding:7px 12px; font-size:13px; outline:none; }}
.kpis {{ display:grid; grid-template-columns:repeat(6,1fr); gap:12px; margin-bottom:14px; }}
.kpi {{ background:linear-gradient(160deg,{PANEL} 0%,#0E1E2F 100%); border:1px solid rgba(0,209,255,.22);
  border-radius:10px; padding:12px 14px; box-shadow:0 0 18px rgba(0,120,190,.10); }}
.kpi .label {{ font-size:12px; color:#8FA8C0; }}
.kpi .value {{ font-size:26px; font-weight:700; color:{ACCENT}; margin:6px 0 2px; letter-spacing:.5px; }}
.kpi .hint {{ font-size:11px; color:#6E8AA5; }}
.grid {{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; }}
.panel {{ background:rgba(18,38,58,.72); border:1px solid rgba(0,209,255,.14); border-radius:10px;
  padding:6px 8px; overflow:hidden; }}
.panel.wide {{ grid-column:span 2; }}
.panel.full {{ grid-column:span 3; }}
.tablewrap {{ padding:10px 14px 14px; }}
table {{ width:100%; border-collapse:collapse; font-size:11.5px; }}
th {{ text-align:left; color:#8FA8C0; font-weight:400; border-bottom:1px solid rgba(0,209,255,.25); padding:6px; }}
td {{ padding:5px 6px; border-bottom:1px solid rgba(255,255,255,.06); }}
td:nth-child(4) {{ color:{ACCENT}; }}
.footer {{ margin-top:12px; font-size:11px; color:#6E8AA5; display:flex; justify-content:space-between; }}
</style></head>
<body>
<div class="header">
  <div>
    <h1>Online Retail <span>商业数据分析大屏</span></h1>
    <div class="sub">UCI Online Retail｜2010-12 至 2011-11｜£9.63M 销售额 · 18,957 订单 · 4,293 客户</div>
  </div>
  <div class="filter">
    <label for="region" style="font-size:13px;color:#8FA8C0">地区筛选：</label>
    <select id="region">
      <option value="all">全部地区</option>
      <option value="uk">仅英国</option>
      <option value="overseas">仅海外</option>
    </select>
  </div>
</div>
<div class="kpis">
  <div class="kpi"><div class="label">销售额</div><div class="value" id="k-revenue">—</div><div class="hint">12 个月累计</div></div>
  <div class="kpi"><div class="label">订单量</div><div class="value" id="k-orders">—</div><div class="hint">有效发票数</div></div>
  <div class="kpi"><div class="label">客户数</div><div class="value" id="k-customers">—</div><div class="hint">有 ID 客户</div></div>
  <div class="kpi"><div class="label">客单价</div><div class="value" id="k-aov">—</div><div class="hint">销售额 / 订单</div></div>
  <div class="kpi"><div class="label">复购率</div><div class="value" id="k-repeat">—</div><div class="hint">购买 ≥2 次占比</div></div>
  <div class="kpi"><div class="label">高价值客户贡献</div><div class="value" id="k-vip">—</div><div class="hint">重要价值+重要保持</div></div>
</div>
<div class="grid">
  <div class="panel wide">{embeds['trend']}</div>
  <div class="panel">{embeds['pie']}</div>
  <div class="panel">{embeds['country']}</div>
  <div class="panel">{embeds['product']}</div>
  <div class="panel">{embeds['heat']}</div>
  <div class="panel">{embeds['scatter']}</div>
  <div class="panel wide"><div class="tablewrap">
      <div style="font-size:14px;font-weight:700;margin:4px 0 8px">高价值客户 TOP10</div>
      <table><thead><tr><th>客户 ID</th><th>RFM 分群</th><th>购买频次</th><th>累计消费</th><th>最近购买距今</th></tr></thead>
      <tbody>{charts['table']}</tbody></table></div></div>
  <div class="panel">{tl_embed}</div>
</div>
<div class="footer">
  <div>数据来源：UCI Machine Learning Repository · Online Retail（官方公开 ZIP 下载，非爬虫）</div>
  <div>图表全部由 Python（Pandas + Pyecharts）生成</div>
</div>
<script>
const DATA = {json.dumps(payload, ensure_ascii=False)};
const IDS = {json.dumps(ids)};

function setKPI(k) {{
  document.getElementById('k-revenue').textContent = k.revenue;
  document.getElementById('k-orders').textContent = k.orders;
  document.getElementById('k-customers').textContent = k.customers;
  document.getElementById('k-aov').textContent = k.aov;
  document.getElementById('k-repeat').textContent = k.repeat;
  document.getElementById('k-vip').textContent = k.vip;
}}
function chartById(id) {{ return echarts.getInstanceByDom(document.getElementById(id)); }}
setKPI(DATA.all.kpi);

document.getElementById('region').addEventListener('change', function (e) {{
  const d = DATA[e.target.value];
  setKPI(d.kpi);
  const trend = chartById(IDS.trend);
  if (trend) {{
    trend.setOption({{
      xAxis: [{{data: d.monthly.month}}],
      series: [{{data: d.monthly.revenue}}, {{data: d.monthly.orders}}]
    }});
  }}
  const product = chartById(IDS.product);
  if (product) {{
    product.setOption({{
      yAxis: [{{data: d.products.name.slice().reverse()}}],
      series: [{{data: d.products.value.slice().reverse()}}]
    }});
  }}
}});
</script>
</body></html>"""
    OUT.write_text(html, encoding="utf-8")
    print(f"[dash] 已生成 {OUT}（{OUT.stat().st_size / 1024:.0f} KB，内联 ECharts）")


def main() -> None:
    t = load()
    charts = build_charts(t)
    render(t, charts)


if __name__ == "__main__":
    main()
