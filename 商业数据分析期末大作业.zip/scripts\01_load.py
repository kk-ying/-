"""01_load.py —— 合规获取与原始数据落地

数据来源：UCI Machine Learning Repository, "Online Retail" (ID=352)
官方页面：https://archive.ics.uci.edu/dataset/352/online+retail
下载地址：https://archive.ics.uci.edu/static/public/352/online+retail.zip
获取方式：官方公开 ZIP 下载（白名单第 1 类：数据源官方一次性下载文件），全程未使用爬虫。

本脚本职责：
1) 若 raw/ 下无 xlsx，则用官方 URL 下载并解压（合规下载，可重复执行）；
2) 读取 Excel，统一字段命名与类型，落地为 raw/online_retail_raw.csv；
3) 输出原始数据概览 JSON，供后续清洗脚本与论文引用。
"""
from __future__ import annotations

import urllib.request
import zipfile

import pandas as pd

from common import RAW_DIR, RAW_XLSX, RAW_CSV, save_json

URL = "https://archive.ics.uci.edu/static/public/352/online+retail.zip"
ZIP_PATH = RAW_DIR / "online_retail.zip"


def ensure_raw_file() -> None:
    """合规下载：官方 ZIP 一次性下载，不使用任何网页抓取/爬虫技术。"""
    if RAW_XLSX.exists():
        print(f"[load] 已存在原始文件：{RAW_XLSX.name}")
        return
    print(f"[load] 从官方地址下载：{URL}")
    urllib.request.urlretrieve(URL, ZIP_PATH)
    with zipfile.ZipFile(ZIP_PATH) as zf:
        zf.extractall(RAW_DIR)
    print("[load] 解压完成")


def main() -> None:
    ensure_raw_file()

    # 读取 Excel（保留原始列名用于核对）
    df = pd.read_excel(RAW_XLSX)
    df.columns = [c.strip().replace(" ", "") for c in df.columns]
    df = df.rename(columns={"CustomerID": "CustomerID"})

    # 类型统一：客户 ID 允许为空，其余字段强类型
    df["InvoiceNo"] = df["InvoiceNo"].astype(str).str.strip()
    df["StockCode"] = df["StockCode"].astype(str).str.strip()
    df["Description"] = df["Description"].astype("string").str.strip()
    df["Country"] = df["Country"].astype(str).str.strip()
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"])
    df["CustomerID"] = pd.to_numeric(df["CustomerID"], errors="coerce")
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce").fillna(0).astype("int64")
    df["UnitPrice"] = pd.to_numeric(df["UnitPrice"], errors="coerce").fillna(0.0)

    df.to_csv(RAW_CSV, index=False, encoding="utf-8-sig")

    summary = {
        "data_source": "UCI Machine Learning Repository - Online Retail (ID 352)",
        "official_url": "https://archive.ics.uci.edu/dataset/352/online+retail",
        "download_url": URL,
        "access_method": "官方公开 ZIP 一次性下载（非爬虫）",
        "license": "CC BY 4.0（UCI 数据集通用许可，允许教学与研究使用）",
        "access_date": "2026-10-29",
        "rows": int(len(df)),
        "columns": list(df.columns),
        "dtypes": {k: str(v) for k, v in df.dtypes.items()},
        "invoice_count": int(df["InvoiceNo"].nunique()),
        "customer_count": int(df["CustomerID"].nunique()),
        "stockcode_count": int(df["StockCode"].nunique()),
        "country_count": int(df["Country"].nunique()),
        "date_min": str(df["InvoiceDate"].min()),
        "date_max": str(df["InvoiceDate"].max()),
        "missing": {k: int(v) for k, v in df.isna().sum().items()},
        "negative_quantity_rows": int((df["Quantity"] < 0).sum()),
        "nonpositive_price_rows": int((df["UnitPrice"] <= 0).sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "return_invoice_rows": int(df["InvoiceNo"].str.startswith("C").sum()),
    }
    save_json(summary, "raw_data_profile.json")
    print(f"[load] 原始记录 {len(df):,} 行，{df['InvoiceNo'].nunique():,} 张发票，"
          f"{df['CustomerID'].nunique():,} 位客户，时间 {df['InvoiceDate'].min():%Y-%m-%d} ~ {df['InvoiceDate'].max():%Y-%m-%d}")


if __name__ == "__main__":
    main()
