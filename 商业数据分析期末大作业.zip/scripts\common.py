"""公共配置：路径、中文字体、配色与绘图工具。

所有脚本共用本模块，保证图表风格统一、输出路径一致。
"""
from __future__ import annotations

import json
import matplotlib
matplotlib.use("Agg")  # 无界面后端，保证可批量出图
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from pathlib import Path

# ---------------------------------------------------------------- 路径
BASE_DIR = Path(__file__).resolve().parents[1]
RAW_DIR = BASE_DIR / "data" / "raw"
CLEAN_DIR = BASE_DIR / "data" / "clean"
FIG_DIR = BASE_DIR / "outputs" / "figures"
TAB_DIR = BASE_DIR / "outputs" / "tables"
DOC_DIR = BASE_DIR / "docs"
for _d in (RAW_DIR, CLEAN_DIR, FIG_DIR, TAB_DIR, DOC_DIR):
    _d.mkdir(parents=True, exist_ok=True)

RAW_XLSX = RAW_DIR / "Online Retail.xlsx"
RAW_CSV = RAW_DIR / "online_retail_raw.csv"
ALL_CSV = CLEAN_DIR / "transactions_all.csv"
CUST_CSV = CLEAN_DIR / "transactions_customer.csv"
RETURN_CSV = CLEAN_DIR / "returns.csv"
DB_PATH = CLEAN_DIR / "retail.db"

# 分析窗口：剔除 2011-12 的不完整月份，保证 12 个完整自然月
WINDOW_START = "2010-12-01"
WINDOW_END = "2011-11-30"
RANDOM_SEED = 42

# ---------------------------------------------------------------- 字体
CJK_FONT = "Microsoft YaHei"
plt.rcParams["font.sans-serif"] = [CJK_FONT, "SimHei", "DejaVu Sans"]
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150
plt.rcParams["savefig.dpi"] = 200
plt.rcParams["axes.edgecolor"] = "#8A8A8A"
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["axes.grid"] = True
plt.rcParams["grid.color"] = "#E3E3E3"
plt.rcParams["grid.linewidth"] = 0.7

# ---------------------------------------------------------------- 配色
COLORS = {
    "navy": "#1F4E79",
    "blue": "#2E75B6",
    "lightblue": "#9DC3E6",
    "orange": "#ED7D31",
    "yellow": "#FFC000",
    "green": "#548235",
    "teal": "#2E8B8B",
    "red": "#C00000",
    "gray": "#7F7F7F",
    "lightgray": "#D9D9D9",
}
PALETTE = ["#1F4E79", "#2E75B6", "#ED7D31", "#FFC000", "#548235",
           "#2E8B8B", "#9DC3E6", "#A6A6A6", "#C00000", "#4472C4"]
# 大屏暗色主题
DARK_BG = "#0B1726"
DARK_PANEL = "#12263A"
DARK_ACCENT = "#00D1FF"
DARK_TEXT = "#E6F1FF"


def money_fmt(x, _pos=None):
    """金额坐标轴：自动显示万/亿。"""
    if abs(x) >= 1e8:
        return f"{x / 1e8:.2f}亿"
    if abs(x) >= 1e4:
        return f"{x / 1e4:.0f}万"
    return f"{x:.0f}"


def save_fig(fig, name: str, tight: bool = True):
    """统一保存：150dpi 以上、去除多余留白、打印文件路径。"""
    if tight:
        fig.tight_layout()
    path = FIG_DIR / name
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"[figure] {path.name}")
    return path


def save_table(df, name: str):
    path = TAB_DIR / name
    df.to_csv(path, index=False, encoding="utf-8-sig")
    print(f"[table ] {path.name}")
    return path


def save_json(obj, name: str):
    path = TAB_DIR / name
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[json  ] {path.name}")
    return path


def style_axes(ax, title=None, xlabel=None, ylabel=None, legend=False):
    """统一的坐标轴样式：标题左对齐加粗、单位标注、网格弱化。"""
    if title:
        ax.set_title(title, fontsize=15, fontweight="bold", loc="left", pad=12)
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=11)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=11)
    if legend:
        ax.legend(frameon=False, fontsize=10)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(labelsize=10, colors="#404040")
    return ax


def annotate_bars(ax, bars, values, fmt="{:,.0f}", offset=0.02):
    """为柱状图统一添加数值标签。"""
    ymax = max(values) if len(values) else 1
    for b, v in zip(bars, values):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + ymax * offset,
                fmt.format(v), ha="center", va="bottom", fontsize=8.5, color="#404040")
