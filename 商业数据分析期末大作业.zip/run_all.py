"""run_all.py —— 一键复现全流程

依次执行 01_load → 02_clean → 03_analysis → 04_visuals → 05_dashboard。
任一环节失败即中止，并在控制台打印失败步骤。

用法：
    python run_all.py            # 完整复现（首次运行会下载官方数据，约 4.5 万行原始 Excel，需联网）
    python run_all.py --from 3    # 从第 3 步开始（数据已就绪时可跳过下载与清洗）
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SCRIPT_DIR = BASE_DIR / "scripts"

STEPS = [
    ("01_load.py", "数据获取：官方 ZIP 下载 + 原始数据落地"),
    ("02_clean.py", "数据清洗：去重/退货/异常/缺失 + 派生指标 + SQLite"),
    ("03_analysis.py", "商业模型：RFM/同期群/帕累托/波士顿/漏斗/关联规则/SARIMA"),
    ("04_visuals.py", "可视化：fig01–fig20 图表与图表索引"),
    ("05_dashboard.py", "交互大屏：outputs/dashboard.html"),
]


def main() -> int:
    parser = argparse.ArgumentParser(description="一键复现《商业数据分析》期末大作业全流程")
    parser.add_argument("--from", dest="start", type=int, default=1,
                        help="从第几步开始执行（1–5，默认 1）")
    parser.add_argument("--python", dest="python", default=sys.executable,
                        help="指定 Python 解释器（默认当前解释器）")
    args = parser.parse_args()

    if not 1 <= args.start <= len(STEPS):
        print(f"[run_all] --from 取值范围为 1–{len(STEPS)}")
        return 2

    t0 = time.time()
    for i, (script, desc) in enumerate(STEPS, start=1):
        if i < args.start:
            print(f"[run_all] 跳过步骤 {i}：{desc}")
            continue
        print(f"\n[run_all] ===== 步骤 {i}/{len(STEPS)}：{desc} =====")
        started = time.time()
        result = subprocess.run([args.python, str(SCRIPT_DIR / script)], cwd=SCRIPT_DIR)
        if result.returncode != 0:
            print(f"[run_all] 步骤 {i} 执行失败（退出码 {result.returncode}），流程中止。")
            return result.returncode
        print(f"[run_all] 步骤 {i} 完成，耗时 {time.time() - started:.1f}s")

    print(f"\n[run_all] 全部完成，总耗时 {time.time() - t0:.1f}s")
    print(f"[run_all] 图表目录：{BASE_DIR / 'outputs' / 'figures'}")
    print(f"[run_all] 交互大屏：{BASE_DIR / 'outputs' / 'dashboard.html'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
