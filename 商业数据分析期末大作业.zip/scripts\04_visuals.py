"""04_visuals.py —— 全 Python 可视化（Matplotlib / Seaborn）

共 20 张图：
- 模板复现类 12 张（fig01–fig10、fig15、fig20），对照《Excel 数据可视化——从图表到数据大屏》
  中的折线图、组合图、条形图、环形图、堆积面积图、玫瑰图、箱线图、树状图、热力图、
  散点图、瀑布图、指标卡模板复现；
- 业务模型类 8 张（fig11–fig14、fig16–fig19），与第 4 章模型一一对应。
统一规范：中文字体、坐标轴与单位、图例位置、配色、200dpi、命名 figNN_名称.png。
"""
from __future__ import annotations

import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch, Polygon, Rectangle
from matplotlib.ticker import FuncFormatter

from common import (ALL_CSV, COLORS, FIG_DIR, PALETTE, TAB_DIR, money_fmt,
                    save_fig, save_json, style_axes)

SRC = "数据来源：UCI Online Retail（2010-12 至 2011-11，清洗后 497,784 行）"


def load_tables():
    t = {}
    for name in ["table02_monthly_sales", "table03_country_sales", "table04_product_sales",
                 "table06_rfm_segments", "table07_segment_monthly", "table08_cohort_retention",
                 "table09_cohort_avg", "table10_boston_matrix", "table11_repurchase_funnel",
                 "table12_association_rules", "table13_sarima_forecast", "table15_hour_weekday"]:
        t[name] = pd.read_csv(TAB_DIR / f"{name}.csv")
    t["summary"] = json.loads((TAB_DIR / "analysis_summary.json").read_text(encoding="utf-8"))
    t["clog"] = json.loads((TAB_DIR / "cleaning_log.json").read_text(encoding="utf-8"))
    t["clean"] = pd.read_csv(ALL_CSV, parse_dates=["InvoiceDay"], dtype={"InvoiceNo": str})
    t["clean"] = t["clean"][t["clean"]["InAnalysisWindow"] == 1]
    return t


def note(fig, src=SRC):
    fig.text(0.99, 0.005, src, ha="right", va="bottom", fontsize=8, color="#808080")


# ------------------------------------------------------------------ fig01
def fig01(m):
    fig, ax = plt.subplots(figsize=(10, 5.2))
    x = np.arange(len(m))
    ax.fill_between(x, m["revenue"], color=COLORS["lightblue"], alpha=0.35)
    ax.plot(x, m["revenue"], color=COLORS["navy"], marker="o", linewidth=2.2,
            markersize=5, label="月度销售额")
    ax.plot(x, m["ma3"], color=COLORS["orange"], linestyle="--", linewidth=1.8, label="3 月移动平均")
    ax.set_xticks(x)
    ax.set_xticklabels(m["YearMonth"], rotation=45)
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    style_axes(ax, "图 1  月度销售额趋势（折线图模板复现）", ylabel="销售额（£）", legend=True)
    peak = int(m["revenue"].idxmax())
    ax.annotate(f"峰值 £{m.loc[peak, 'revenue']:,.0f}\n{m.loc[peak, 'YearMonth']}",
                xy=(peak, m.loc[peak, "revenue"]), xytext=(peak - 3.2, m.loc[peak, "revenue"] * 0.93),
                fontsize=9, arrowprops=dict(arrowstyle="->", color=COLORS["red"]), color=COLORS["red"])
    note(fig)
    return save_fig(fig, "fig01_月度销售额趋势.png")


# ------------------------------------------------------------------ fig02
def fig02(m):
    fig, ax1 = plt.subplots(figsize=(10, 5.2))
    x = np.arange(len(m))
    bars = ax1.bar(x, m["orders"], color=COLORS["lightblue"], edgecolor="white", width=0.62,
                   label="订单量（左轴）")
    ax1.set_xticks(x)
    ax1.set_xticklabels(m["YearMonth"], rotation=45)
    ax1.set_ylabel("订单量（单）", color=COLORS["navy"])
    style_axes(ax1, "图 2  月度订单量与客单价（组合图模板复现）")
    for b, v in zip(bars, m["orders"]):
        ax1.text(b.get_x() + b.get_width() / 2, b.get_height() + 30, f"{v:,}",
                 ha="center", fontsize=7.5, color="#404040")

    ax2 = ax1.twinx()
    ax2.plot(x, m["aov"], color=COLORS["orange"], marker="D", linewidth=2, markersize=5,
             label="客单价（右轴）")
    ax2.set_ylabel("客单价（£/单）", color=COLORS["orange"])
    ax2.grid(False)
    ax2.spines["top"].set_visible(False)
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper left", frameon=False, fontsize=9)
    note(fig)
    return save_fig(fig, "fig02_月度订单量与客单价.png")


# ------------------------------------------------------------------ fig03
def fig03(c):
    d = c[c["Country"] != "United Kingdom"].head(10).iloc[::-1]
    fig, ax = plt.subplots(figsize=(9.5, 5.6))
    bars = ax.barh(d["Country"], d["revenue"], color=COLORS["navy"], height=0.62)
    bars[-1].set_color(COLORS["orange"])
    for b, v in zip(bars, d["revenue"]):
        ax.text(v + d["revenue"].max() * 0.015, b.get_y() + b.get_height() / 2, f"£{v:,.0f}",
                va="center", fontsize=9)
    ax.xaxis.set_major_formatter(FuncFormatter(money_fmt))
    uk = c[c.Country == "United Kingdom"]["share"].iloc[0]
    style_axes(ax, "图 3  英国以外 Top10 国家销售额（条形图模板复现）", xlabel="销售额（£）")
    ax.text(0.99, 0.03, f"英国本土销售额占比 {uk:.1f}%，未在图中展示", transform=ax.transAxes,
            ha="right", fontsize=9, color="#606060")
    note(fig)
    return save_fig(fig, "fig03_国家销售额Top10.png")


# ------------------------------------------------------------------ fig04
def fig04(c):
    d = c[c["Country"] != "United Kingdom"].head(8).copy()
    other = c[(c["Country"] != "United Kingdom")].iloc[8:]["revenue"].sum()
    uk = c[c.Country == "United Kingdom"]["revenue"].iloc[0]
    labels = ["英国"] + d["Country"].tolist() + ["其他"]
    values = [uk] + d["revenue"].tolist() + [other]
    fig, ax = plt.subplots(figsize=(7.6, 6.2))
    colors = [COLORS["navy"], COLORS["orange"], COLORS["blue"], COLORS["yellow"],
              COLORS["teal"], COLORS["green"], COLORS["lightblue"], COLORS["gray"],
              COLORS["red"], COLORS["lightgray"]]
    wedges, _ = ax.pie(values, colors=colors, startangle=90, counterclock=False,
                       wedgeprops=dict(width=0.42, edgecolor="white", linewidth=1.4))
    ax.text(0, 0, f"总销售额\n£{sum(values) / 1e6:.2f}M", ha="center", va="center",
            fontsize=13, fontweight="bold", color=COLORS["navy"])
    ax.legend(wedges, [f"{l}  {v / sum(values) * 100:.1f}%" for l, v in zip(labels, values)],
              loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False, fontsize=9)
    ax.set_title("图 4  销售额国家结构（环形图模板复现）", fontsize=15, fontweight="bold", loc="left")
    note(fig)
    return save_fig(fig, "fig04_国家销售额结构.png")


# ------------------------------------------------------------------ fig05
def fig05(sm, seg):
    order = seg.sort_values("revenue", ascending=False)["segment"].tolist()
    p = sm.pivot_table(index="YearMonth", columns="segment", values="Revenue", aggfunc="sum").fillna(0)
    p = p[order]
    colors = ["#1F4E79", "#2E75B6", "#ED7D31", "#FFC000", "#548235", "#2E8B8B", "#9DC3E6", "#A6A6A6"]
    fig, ax = plt.subplots(figsize=(10.5, 5.6))
    ax.stackplot(p.index, [p[c] for c in p.columns], labels=p.columns, colors=colors, alpha=0.92)
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    style_axes(ax, "图 5  八类客户群月度销售额构成（堆积面积图模板复现）", ylabel="销售额（£）")
    ax.legend(loc="upper left", frameon=False, ncol=4, fontsize=9)
    ax.tick_params(axis="x", rotation=45)
    note(fig)
    return save_fig(fig, "fig05_客户群月度销售额构成.png")


# ------------------------------------------------------------------ fig06
def fig06(m):
    fig = plt.figure(figsize=(8.6, 6.2))
    ax = fig.add_subplot(111, projection="polar")
    months = [x[5:] + "月" for x in m["YearMonth"]]
    theta = np.linspace(0, 2 * np.pi, len(m), endpoint=False)
    width = 2 * np.pi / len(m) * 0.9
    vals = m["revenue"].values
    colors = plt.cm.YlGnBu(np.linspace(0.35, 1, len(m)))
    bars = ax.bar(theta, vals, width=width, color=colors, edgecolor="white")
    ax.set_theta_zero_location("N")
    ax.set_theta_direction(-1)
    ax.set_xticks(theta)
    ax.set_xticklabels(months, fontsize=9)
    ax.set_yticklabels([])
    ax.spines["polar"].set_visible(False)
    for t, v in zip(theta, vals):
        ax.text(t, v + vals.max() * 0.03, f"{v / 1e4:.0f}万", ha="center", fontsize=8,
                color="#404040")
    ax.set_title("图 6  月度销售额分布（玫瑰图模板复现）", fontsize=15, fontweight="bold", loc="left", pad=22)
    note(fig)
    return save_fig(fig, "fig06_月度销售额玫瑰图.png")


# ------------------------------------------------------------------ fig07
def fig07(df, c):
    top = [x for x in c["Country"].head(6).tolist()]
    data = [df[df["Country"] == k].groupby("InvoiceNo")["Revenue"].sum().values for k in top]
    names = ["英国" if k == "United Kingdom" else k for k in top]
    fig, ax = plt.subplots(figsize=(9.6, 5.4))
    bp = ax.boxplot(data, tick_labels=names, patch_artist=True, widths=0.55, showfliers=False,
                    medianprops=dict(color=COLORS["orange"], linewidth=2))
    for patch, col in zip(bp["boxes"], [COLORS["navy"], COLORS["blue"], COLORS["teal"],
                                        COLORS["green"], COLORS["yellow"], COLORS["gray"]]):
        patch.set_facecolor(col)
        patch.set_alpha(0.75)
    ax.set_yscale("log")
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    style_axes(ax, "图 7  主要国家订单金额分布（箱线图模板复现）", ylabel="订单金额（£，对数轴）")
    ax.text(0.99, 0.95, "已隐藏离群点，虚线为整体中位数", transform=ax.transAxes,
            ha="right", fontsize=9, color="#606060")
    note(fig)
    return save_fig(fig, "fig07_订单金额分布箱线图.png")


# ------------------------------------------------------------------ fig08
def treemap(values, x, y, w, h, horizontal=True):
    if not values:
        return []
    if len(values) == 1:
        return [(x, y, w, h)]
    total = sum(values)
    acc, i = 0.0, 0
    while i < len(values) - 1 and acc + values[i] <= total / 2:
        acc += values[i]
        i += 1
    i = max(i, 1)
    ratio = sum(values[:i]) / total
    if horizontal:
        return (treemap(values[:i], x, y, w * ratio, h, False) +
                treemap(values[i:], x + w * ratio, y, w * (1 - ratio), h, False))
    return (treemap(values[:i], x, y, w, h * ratio, True) +
            treemap(values[i:], x, y + h * ratio, w, h * (1 - ratio), True))


def fig08(p):
    d = p.head(15).copy()
    d["short"] = d["Description"].str.title().str.slice(0, 14)
    values = d["revenue"].tolist()
    rects = treemap(values, 0, 0, 1, 1)
    fig, ax = plt.subplots(figsize=(10, 5.8))
    cmap = plt.cm.YlGnBu
    mx = max(values)
    for (x, y, w, h), (_, row), v in zip(rects, d.iterrows(), values):
        ax.add_patch(Rectangle((x, y), w, h, facecolor=cmap(0.25 + 0.65 * v / mx),
                               edgecolor="white", linewidth=2))
        if w * h > 0.02:
            ax.text(x + w / 2, y + h / 2, f"{row['short']}\n£{v / 1e4:.1f}万",
                    ha="center", va="center", fontsize=8.5,
                    color="white" if v / mx > 0.5 else "#203040")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    ax.set_title("图 8  商品销售额结构（树状图模板复现，Top15）", fontsize=15, fontweight="bold", loc="left")
    note(fig)
    return save_fig(fig, "fig08_商品销售额树状图.png")


# ------------------------------------------------------------------ fig09
def fig09(hw):
    data = hw.set_index("Hour").T
    fig, ax = plt.subplots(figsize=(10.4, 4.8))
    im = ax.imshow(data.values, aspect="auto", cmap="YlOrRd")
    ax.set_xticks(range(len(data.columns)))
    ax.set_xticklabels([f"{h}时" for h in data.columns], fontsize=8, rotation=0)
    ax.set_yticks(range(len(data.index)))
    ax.set_yticklabels(data.index, fontsize=9)
    ax.grid(False)
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            v = data.values[i, j]
            if v > 0:
                ax.text(j, i, f"{v / 1e4:.1f}", ha="center", va="center", fontsize=7.5,
                        color="white" if v > data.values.max() * 0.55 else "#333333")
    cb = fig.colorbar(im, ax=ax, pad=0.015, fraction=0.03)
    cb.set_label("销售额（万 £）", fontsize=9)
    ax.set_title("图 9  下单时段 × 星期销售额热力图（热力图模板复现）",
                 fontsize=15, fontweight="bold", loc="left")
    note(fig)
    return save_fig(fig, "fig09_时段星期热力图.png")


# ------------------------------------------------------------------ fig10
def fig10(df):
    g = df.dropna(subset=["CustomerID"]).groupby("CustomerID").agg(
        f=("InvoiceNo", "nunique"), m=("Revenue", "sum"))
    g["aov"] = g["m"] / g["f"]
    fig, ax = plt.subplots(figsize=(9.4, 5.4))
    sc = ax.scatter(g["f"], g["aov"], s=14, c=np.log10(g["m"]), cmap="viridis",
                    alpha=0.55, edgecolors="none")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:.0f}"))
    style_axes(ax, "图 10  购买频次与客单价关系（散点图模板复现）",
               xlabel="购买频次（次，对数轴）", ylabel="客单价（£，对数轴）")
    cb = fig.colorbar(sc, ax=ax, pad=0.015, fraction=0.03)
    cb.set_label("客户累计消费 log10(£)", fontsize=9)
    ax.text(0.02, 0.96, f"n={len(g):,} 位有 ID 客户", transform=ax.transAxes,
            fontsize=9, color="#404040", va="top")
    note(fig)
    return save_fig(fig, "fig10_购买频次与客单价散点.png")


# ------------------------------------------------------------------ fig11
def fig11(seg):
    axes_names = ["R 最近购买", "F 购买频次", "M 消费金额", "收入贡献"]
    pick = ["重要价值客户", "重要保持客户", "重要挽留客户", "一般挽留客户"]
    d = seg.set_index("segment").loc[pick]
    prof = np.column_stack([
        d["avg_r_score"] / 5, d["avg_f_score"] / 5, d["avg_m_score"] / 5,
        d["revenue_share"] / 100,
    ])
    angles = np.linspace(0, 2 * np.pi, len(axes_names), endpoint=False).tolist()
    angles += angles[:1]
    fig = plt.figure(figsize=(7.4, 6.4))
    ax = fig.add_subplot(111, projection="polar")
    colors = [COLORS["navy"], COLORS["orange"], COLORS["teal"], COLORS["gray"]]
    for i, name in enumerate(pick):
        vals = prof[i].tolist() + [prof[i][0]]
        ax.plot(angles, vals, color=colors[i], linewidth=2, label=name)
        ax.fill(angles, vals, color=colors[i], alpha=0.12)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(axes_names, fontsize=11)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0.25", "0.5", "0.75", "1.0"], fontsize=8, color="#808080")
    ax.set_title("图 11  四类核心客户群 RFM 画像（雷达图）", fontsize=15, fontweight="bold",
                 loc="left", pad=24)
    ax.legend(loc="lower right", bbox_to_anchor=(1.25, -0.05), frameon=False, fontsize=9)
    note(fig)
    return save_fig(fig, "fig11_RFM客户群雷达图.png")


# ------------------------------------------------------------------ fig12
def fig12(df, seg):
    cust = pd.read_csv(TAB_DIR / "table05_rfm_customers.csv")
    fig, ax = plt.subplots(figsize=(10, 5.8))
    cmap = {"重要价值客户": COLORS["navy"], "重要保持客户": COLORS["orange"],
            "重要发展客户": COLORS["yellow"], "重要挽留客户": COLORS["red"],
            "一般价值客户": COLORS["blue"], "一般保持客户": COLORS["teal"],
            "一般发展客户": COLORS["green"], "一般挽留客户": COLORS["lightgray"]}
    for name, g in cust.groupby("segment"):
        ax.scatter(g["frequency"], g["monetary"], s=np.clip(g["recency"] * 0.35, 8, 60),
                   c=cmap.get(name, "#999999"), alpha=0.5, label=name, edgecolors="none")
    ax.set_yscale("log")
    ax.set_xscale("log")
    ax.set_xlim(0.9, cust["frequency"].max() * 1.1)
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    ax.axvline(cust["frequency"].median(), color="#666666", linestyle=":", linewidth=1)
    ax.axhline(cust["monetary"].median(), color="#666666", linestyle=":", linewidth=1)
    style_axes(ax, "图 12  RFM 客户价值分布（气泡图，气泡大小=最近购买间隔）",
               xlabel="购买频次 F（次，对数轴）", ylabel="消费金额 M（£，对数轴）")
    ax.legend(loc="lower right", frameon=False, fontsize=8, ncol=2)
    note(fig)
    return save_fig(fig, "fig12_RFM客户价值气泡图.png")


# ------------------------------------------------------------------ fig13
def fig13(ret):
    d = ret.set_index("cohort").drop(columns=["cohort_size"])
    d = d.loc[:, d.notna().any()]     # 去掉完全没有观测的窗口（如 M12）
    fig, ax = plt.subplots(figsize=(11, 6.2))
    masked = np.ma.masked_invalid(d.values)
    cmap = plt.cm.YlGnBu.copy()
    cmap.set_bad("#EFEFEF")
    im = ax.imshow(masked, aspect="auto", cmap=cmap, vmin=0, vmax=60)
    ax.set_xticks(range(d.shape[1]))
    ax.set_xticklabels([f"M{c}" for c in d.columns], fontsize=9)
    ax.set_yticks(range(d.shape[0]))
    ax.set_yticklabels(d.index, fontsize=9)
    ax.grid(False)
    for i in range(d.shape[0]):
        for j in range(d.shape[1]):
            v = d.values[i, j]
            if not np.isnan(v):
                ax.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=7.5,
                        color="white" if v > 35 else "#333333")
    cb = fig.colorbar(im, ax=ax, pad=0.015, fraction=0.03)
    cb.set_label("留存率（%）", fontsize=9)
    ax.set_title("图 13  同期群 30 天窗口留存热力图（首购月份 × 距首购月数）",
                 fontsize=15, fontweight="bold", loc="left")
    note(fig)
    return save_fig(fig, "fig13_同期群留存热力图.png")


# ------------------------------------------------------------------ fig14
def fig14(p):
    d = p.head(30).copy()
    fig, ax = plt.subplots(figsize=(10.4, 5.6))
    colmap = {"A": COLORS["navy"], "B": COLORS["orange"], "C": COLORS["gray"]}
    colors = [colmap[c] for c in d["abc_class"]]
    x = np.arange(len(d))
    ax.bar(x, d["revenue"], color=colors, width=0.72)
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    ax.set_xticks(x)
    ax.set_xticklabels([f"P{i + 1}" for i in x], fontsize=9)
    ax2 = ax.twinx()
    ax2.plot(x, d["cum_share"], color=COLORS["red"], marker="o", markersize=4, linewidth=1.8)
    ax2.axhline(80, color=COLORS["red"], linestyle="--", linewidth=1.2)
    ax2.set_ylim(0, 105)
    ax2.set_ylabel("累计销售额占比（%）", color=COLORS["red"])
    ax2.grid(False)
    ax2.spines["top"].set_visible(False)
    style_axes(ax, "图 14  商品销售额帕累托图与 ABC 分类", ylabel="单品销售额（£）")
    ax.text(0.01, 0.94, "A 类（累计 80%）", transform=ax.transAxes, color=COLORS["navy"], fontsize=9)
    ax.text(0.16, 0.94, "B 类（80%–95%）", transform=ax.transAxes, color=COLORS["orange"], fontsize=9)
    ax.text(0.34, 0.94, "C 类（>95%）", transform=ax.transAxes, color=COLORS["gray"], fontsize=9)
    note(fig)
    return save_fig(fig, "fig14_商品帕累托图.png")


# ------------------------------------------------------------------ fig15
def fig15(m):
    vals = m["revenue"].values
    deltas = np.diff(vals, prepend=0)
    fig, ax = plt.subplots(figsize=(10.4, 5.4))
    running = 0
    for i, (mo, dlt) in enumerate(zip(m["YearMonth"], deltas)):
        base = running if i > 0 else 0
        color = COLORS["green"] if dlt >= 0 else COLORS["red"]
        ax.bar(i, dlt, bottom=base, color=color, width=0.62)
        if i > 0:
            ax.plot([i - 0.31, i + 0.31], [running, running], color="#888888", linewidth=0.8, zorder=0)
        running += dlt
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    ax.set_xticks(range(len(m)))
    ax.set_xticklabels(m["YearMonth"], rotation=45)
    style_axes(ax, "图 15  月度销售额环比增减瀑布图（瀑布图模板复现）", ylabel="销售额（£）")
    ax.text(0.01, 0.96, "绿色=环比上升，红色=环比下降", transform=ax.transAxes,
            fontsize=9, color="#404040", va="top")
    note(fig)
    return save_fig(fig, "fig15_月度环比瀑布图.png")


# ------------------------------------------------------------------ fig16
def fig16(f):
    fig, ax = plt.subplots(figsize=(9.4, 5.6))
    n = len(f)
    ys = np.arange(n)[::-1]
    maxv = f["customers"].iloc[0]
    for i, row in f.iterrows():
        w = row["customers"] / maxv * 0.78
        ax.add_patch(Polygon([[0.5 - w / 2, ys[i] - 0.34], [0.5 + w / 2, ys[i] - 0.34],
                              [0.5 + w / 2, ys[i] + 0.34], [0.5 - w / 2, ys[i] + 0.34]],
                             closed=True, facecolor=PALETTE[i % len(PALETTE)], alpha=0.85,
                             edgecolor="white", linewidth=2))
        ax.text(0.5, ys[i], f"{row['stage']}：{row['customers']:,} 人", ha="center",
                va="center", fontsize=11, color="white", fontweight="bold")
        if i > 0:
            ax.text(0.985, ys[i], f"占全部客户 {row['conversion_rate']:.1f}%", ha="right",
                    va="center", fontsize=9, color="#404040")
            ax.text(0.015, ys[i], f"相邻层转化 {row['stage_conversion']:.1f}%", ha="left",
                    va="center", fontsize=9, color="#606060")
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.6, n - 0.4)
    ax.axis("off")
    ax.set_title("图 16  客户忠诚度漏斗（累计订单数分层）", fontsize=15,
                 fontweight="bold", loc="left")
    note(fig)
    return save_fig(fig, "fig16_复购漏斗图.png")


# ------------------------------------------------------------------ fig17
def fig17(fc, df):
    bt = fc[fc["type"] == "backtest"].copy()
    fu = fc[fc["type"] == "forecast"].copy()
    bt["date"] = pd.to_datetime(bt["date"])
    fu["date"] = pd.to_datetime(fu["date"])

    recent = (df.groupby("InvoiceDay")["Revenue"].sum()
              .loc[bt["date"].min() - pd.Timedelta(days=45):bt["date"].max()])
    fig, ax = plt.subplots(figsize=(11, 5.6))
    ax.plot(recent.index, recent.values, color=COLORS["gray"], linewidth=1.3, label="实际销售额")
    ax.plot(bt["date"], bt["actual"], color=COLORS["navy"], linewidth=1.4, label="回测期实际")
    ax.plot(bt["date"], bt["forecast"], color=COLORS["orange"], linewidth=1.6, label="回测预测")
    ax.fill_between(bt["date"], bt["lower_95"], bt["upper_95"], color=COLORS["orange"], alpha=0.18)
    ax.plot(fu["date"], fu["forecast"], color=COLORS["red"], linewidth=1.8, label="未来 28 天预测")
    ax.fill_between(fu["date"], fu["lower_95"], fu["upper_95"], color=COLORS["red"], alpha=0.2,
                    label="95% 置信区间")
    ax.axvline(bt["date"].max(), color="#666666", linestyle="--", linewidth=1)
    ax.text(bt["date"].max(), ax.get_ylim()[1] * 0.95, " 预测起点", fontsize=9, color="#606060")
    ax.yaxis.set_major_formatter(FuncFormatter(money_fmt))
    style_axes(ax, "图 17  SARIMA 日销售额预测（含 95% 置信区间）", ylabel="日销售额（£）", legend=True)
    ax.legend(loc="upper left", frameon=False, fontsize=8, ncol=2)
    note(fig)
    return save_fig(fig, "fig17_SARIMA预测图.png")


# ------------------------------------------------------------------ fig18
def fig18(b):
    fig, ax = plt.subplots(figsize=(10, 6))
    xm = b["share"].median()
    # 增速极端值（>200% 或 <-60%）截断显示，避免压缩主体分布，并在图中注明
    b = b.copy()
    b["growth_plot"] = b["growth"].clip(-60, 200)
    colors = {"明星产品": COLORS["navy"], "问题产品": COLORS["orange"],
              "现金牛产品": COLORS["green"], "瘦狗产品": COLORS["gray"]}
    for q, g in b.groupby("quadrant"):
        ax.scatter(g["share"], g["growth_plot"], s=np.sqrt(g["revenue"]) * 1.6, alpha=0.8,
                   color=colors[q], label=q, edgecolors="white", linewidth=0.8)
    ax.axvline(xm, color="#666666", linestyle="--", linewidth=1)
    ax.axhline(0, color="#666666", linestyle="--", linewidth=1)

    # 仅标注收入最高的 6 个商品，错位摆放减少重叠
    for i, (_, r) in enumerate(b.head(6).iterrows()):
        dy = 10 if i % 2 == 0 else -14
        ax.annotate(str(r["Description"])[:18], (r["share"], r["growth_plot"]), fontsize=7.5,
                    xytext=(6, dy), textcoords="offset points", color="#303030",
                    arrowprops=dict(arrowstyle="-", color="#B0B0B0", linewidth=0.6))
    ax.set_xlim(0, b["share"].max() * 1.08)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.1f}%"))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.0f}%"))
    style_axes(ax, "图 18  波士顿矩阵：商品收入份额 × 增速", xlabel="销售额份额（%）",
               ylabel="下半年月均销售额增速（%）")
    ax.text(0.99, 0.97, "明星", transform=ax.transAxes, ha="right", va="top", fontsize=14,
            color=COLORS["navy"], fontweight="bold", alpha=0.85)
    ax.text(0.01, 0.97, "问题", transform=ax.transAxes, fontsize=14, color=COLORS["orange"],
            fontweight="bold", alpha=0.85)
    ax.text(0.99, 0.03, "现金牛", transform=ax.transAxes, ha="right", fontsize=14,
            color=COLORS["green"], fontweight="bold", alpha=0.85)
    ax.text(0.01, 0.03, "瘦狗", transform=ax.transAxes, fontsize=14, color=COLORS["gray"],
            fontweight="bold", alpha=0.85)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), ncol=4, frameon=False, fontsize=9)
    ax.text(0.99, 0.90, "增速已截断至 [-60%, 200%] 显示", transform=ax.transAxes,
            ha="right", fontsize=7.5, color="#909090")
    note(fig)
    return save_fig(fig, "fig18_波士顿矩阵.png")


# ------------------------------------------------------------------ fig19
def fig19(r):
    d = r.copy()
    fig, ax = plt.subplots(figsize=(9.4, 5.6))
    sc = ax.scatter(d["support"] * 100, d["confidence"] * 100, s=d["lift"] * 12, c=d["lift"],
                    cmap="plasma", alpha=0.75, edgecolors="white", linewidth=0.6)
    cb = fig.colorbar(sc, ax=ax, pad=0.015, fraction=0.03)
    cb.set_label("提升度 lift", fontsize=9)
    for _, row in d.head(3).iterrows():
        ax.annotate(f"{row['antecedents'][:18]} → {row['consequents'][:14]}",
                    (row["support"] * 100, row["confidence"] * 100), fontsize=7.5,
                    xytext=(6, -8), textcoords="offset points", color="#303030")
    style_axes(ax, "图 19  关联规则支持度—置信度分布（气泡大小=提升度）",
               xlabel="支持度 Support（%）", ylabel="置信度 Confidence（%）")
    note(fig)
    return save_fig(fig, "fig19_关联规则散点图.png")


# ------------------------------------------------------------------ fig20
def fig20(s, m, clog):
    kpis = [
        ("总销售额", f"£{s['revenue'] / 1e6:.2f}M", "12 个月累计"),
        ("订单量", f"{s['orders']:,}", "有效发票数"),
        ("客户数", f"{s['customers']:,}", "有 ID 客户"),
        ("客单价", f"£{s['avg_order_value']:,.0f}", "销售额 / 订单"),
        ("复购率", f"{s['repeat_purchase_rate_%']:.1f}%", "购买 ≥2 次占比"),
        ("退货单占比", f"{clog['return_invoice_rate_%']:.1f}%", "退货单 / 全部发票"),
    ]
    fig, ax = plt.subplots(figsize=(11, 3.4))
    ax.axis("off")
    for i, (title, val, sub) in enumerate(kpis):
        x = i / len(kpis) + 0.006
        w = 1 / len(kpis) - 0.012
        ax.add_patch(FancyBboxPatch((x, 0.08), w, 0.84, boxstyle="round,pad=0.012,rounding_size=0.03",
                                    facecolor="#F4F7FA", edgecolor=COLORS["lightblue"], linewidth=1.2,
                                    transform=ax.transAxes, clip_on=False))
        ax.text(x + w / 2, 0.72, title, ha="center", fontsize=11, color="#505050", transform=ax.transAxes)
        ax.text(x + w / 2, 0.44, val, ha="center", fontsize=21, fontweight="bold",
                color=COLORS["navy"], transform=ax.transAxes)
        ax.text(x + w / 2, 0.19, sub, ha="center", fontsize=9, color="#808080", transform=ax.transAxes)
    ax.set_title("图 20  核心 KPI 指标卡（指标卡 / 仪表盘模板复现）", fontsize=15,
                 fontweight="bold", loc="left")
    note(fig)
    return save_fig(fig, "fig20_KPI指标卡.png")


def main() -> None:
    t = load_tables()
    m, c, p = t["table02_monthly_sales"], t["table03_country_sales"], t["table04_product_sales"]
    seg, sm = t["table06_rfm_segments"], t["table07_segment_monthly"]
    df = t["clean"]

    made = [
        fig01(m), fig02(m), fig03(c), fig04(c), fig05(sm, seg), fig06(m),
        fig07(df, c), fig08(p), fig09(t["table15_hour_weekday"]), fig10(df),
        fig11(seg), fig12(df, seg), fig13(t["table08_cohort_retention"]), fig14(p),
        fig15(m), fig16(t["table11_repurchase_funnel"]),
        fig17(t["table13_sarima_forecast"], df), fig18(t["table10_boston_matrix"]),
        fig19(t["table12_association_rules"]), fig20(t["summary"], m, t["clog"]),
    ]
    index = pd.DataFrame({
        "编号": [f"fig{i:02d}" for i in range(1, len(made) + 1)],
        "文件名": [x.name for x in made],
        "类别": ["模板复现"] * 10 + ["业务模型"] * 4 + ["模板复现", "业务模型",
                                                      "业务模型", "业务模型", "业务模型", "模板复现"],
    })
    save_json(index.to_dict("records"), "figure_index.json")
    print(f"[visual] 共输出 {len(made)} 张图，位于 {FIG_DIR}")


if __name__ == "__main__":
    main()
