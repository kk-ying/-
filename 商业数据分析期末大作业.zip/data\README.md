# data/ 数据说明

本目录存放原始数据与清洗后数据。为控制提交包体积（≤25 MB），压缩包内**未包含**
大体积的原始文件与清洗明细，均可通过脚本一键重建：

```bash
python scripts/01_load.py      # 从 UCI 官方地址下载并落地 data/raw
python scripts/02_clean.py     # 生成 data/clean 的 CSV 与 retail.db
```

重建后本目录结构与下表一致。

## 1. 目录与文件

| 路径 | 内容 | 是否随包提供 | 是否可重建 |
|---|---|---|---|
| `raw/Online Retail.xlsx` | UCI 官方原始文件（541,909 行，约 22.6 MB） | 否 | 是（`01_load.py` 自动下载） |
| `raw/online_retail.zip` | 官方下载的原始压缩包（约 22.6 MB） | 否 | 是 |
| `raw/online_retail_raw.csv` | 读取 xlsx 后统一类型落地的原始副本（约 46 MB） | 否 | 是 |
| `clean/transactions_all.csv` | 清洗后全量明细（含窗口标记，约 64 MB） | 否 | 是（`02_clean.py`） |
| `clean/transactions_customer.csv` | 仅含客户 ID 的明细（约 48 MB） | 否 | 是 |
| `clean/returns.csv` | 退货 / 取消单归档（约 0.9 MB） | 是 | 是 |
| `clean/retail.db` | SQLite 数据库，含上述三张表（约 128 MB） | 否 | 是 |

## 2. 原始表结构（主表，8 个字段）

| 字段 | 类型 | 说明 |
|---|---|---|
| `InvoiceNo` | string | 发票号；以 `C` 开头表示退货/取消单，共 9,251 行 |
| `StockCode` | string | 商品编码；`POST`/`M`/`DOT`/`gift_0001_*` 等为非商品类 |
| `Description` | string | 商品名称，存在少量缺失（按 StockCode 众数回填） |
| `Quantity` | int | 数量；负数表示退货，0/负值在清洗中剔除 |
| `InvoiceDate` | datetime | 下单时间，精确到分钟 |
| `UnitPrice` | float | 单价（英镑 £）；0 或负值在清洗中剔除 |
| `CustomerID` | float→int | 客户 ID，缺失约 13.5 万行（匿名散客） |
| `Country` | string | 客户所在国家，共 38 个国家/地区 |

**主键与关联**：原始数据为单表结构，无独立维度表；分析阶段以 `InvoiceNo` 作为订单主键、
`CustomerID` 作为客户主键、`StockCode` 作为商品主键派生维度：
- 订单维：`InvoiceNo` → 销售额、商品数、下单时段；
- 客户维：`CustomerID` → R/F/M、同期群、分群标签；
- 商品维：`StockCode`/`Description` → 帕累托、ABC、波士顿矩阵、关联规则。

## 3. 清洗后新增字段（派生）

| 字段 | 说明 |
|---|---|
| `Revenue` | `Quantity × UnitPrice`（销售额，£） |
| `Year` / `Month` / `YearMonth` | 年 / 月 / 年月，用于月度聚合 |
| `Weekday` | 星期（0=周一，pandas `day_of_week`） |
| `Hour` | 下单小时（0–23） |
| `InvoiceDay` | 下单日期（去掉时分秒），用于日度序列 |
| `IsBulkOrder` | 是否批量订单（同一发票数量 ≥ 100 件） |
| `InAnalysisWindow` | 是否落在分析窗口 `2010-12-01 ~ 2011-11-30`（1/0） |

## 4. 数据规模

- 原始：541,909 行，25,900 张发票，4,372 位有 ID 客户，2010-12-01 ~ 2011-12-09；
- 清洗后：522,537 行（保留率 96.43%），18,957 张销售发票，4,293 位客户，3,904 个商品；
- 分析窗口内：497,784 行，销售额 £9,632,728。

## 5. 读取方式

```python
import pandas as pd
df = pd.read_csv("data/clean/transactions_all.csv",
                 parse_dates=["InvoiceDate", "InvoiceDay"],
                 dtype={"InvoiceNo": str})
df = df[df["InAnalysisWindow"] == 1]

import sqlite3
con = sqlite3.connect("data/clean/retail.db")
print(pd.read_sql("SELECT * FROM transactions_all LIMIT 5", con))
```

> 所有 CSV 均以 `utf-8-sig` 编码写出，Excel 直接打开中文不乱码。
