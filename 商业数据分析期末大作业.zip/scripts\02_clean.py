"""02_clean.py —— 数据清洗与治理

治理流程（每一步均记录行数变化，写入 outputs/tables/cleaning_log.json）：
1. 完全重复行去重；
2. 识别退货/取消单（InvoiceNo 以 C 开头，数量为负），单独归档；
3. 剔除数量 ≤ 0 的调整行、单价 ≤ 0 的赠品行；
4. 剔除非商品类代码（邮费 POST、人工费 M、银行手续费、Amazon 费、礼品券等）；
5. 剔除单价 ≥ 1000 的极端价格异常（120 行，占 0.02%）；
6. 缺失商品描述用同 StockCode 的众数回填，无法回填的记录剔除；
7. 统一日期格式，派生年月、星期、小时、销售额等指标；
8. 分析窗口限定为 12 个完整自然月（2010-12-01 ~ 2011-11-30）；
9. 输出 CSV / SQLite 两种可复用格式。
"""
from __future__ import annotations

import re
import sqlite3

import pandas as pd

from common import (ALL_CSV, CUST_CSV, DB_PATH, RAW_CSV, RETURN_CSV,
                    WINDOW_START, WINDOW_END, save_json, save_table)

PRODUCT_CODE = re.compile(r"^\d{5}[A-Za-z]{0,2}$")
log: list[dict] = []


def step(name: str, before: int, after: int, note: str) -> None:
    log.append({
        "step": name,
        "rows_before": int(before),
        "rows_after": int(after),
        "rows_removed": int(before - after),
        "removal_rate_%": round((before - after) / before * 100, 3) if before else 0,
        "note": note,
    })
    print(f"[clean] {name}: {before:,} → {after:,}（剔除 {before - after:,}）")


def main() -> None:
    df = pd.read_csv(RAW_CSV, dtype={"InvoiceNo": str, "StockCode": str})
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"])
    df["CustomerID"] = pd.to_numeric(df["CustomerID"], errors="coerce")
    n0 = len(df)

    # 1 重复值
    before = len(df)
    df = df.drop_duplicates()
    step("完全重复行去重", before, len(df), "同一发票同一商品同一价格重复录入")

    # 2 退货/取消单拆分
    before = len(df)
    is_return = df["InvoiceNo"].str.startswith("C")
    returns = df.loc[is_return].copy()
    returns["Revenue"] = returns["Quantity"] * returns["UnitPrice"]
    returns["YearMonth"] = returns["InvoiceDate"].dt.strftime("%Y-%m")
    returns.to_csv(RETURN_CSV, index=False, encoding="utf-8-sig")
    df = df.loc[~is_return].copy()
    step("退货/取消单单独归档", before, len(df), "InvoiceNo 以 C 开头，不计入销售额")

    # 3 数量与单价合法性
    before = len(df)
    df = df.loc[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)].copy()
    step("剔除数量≤0或单价≤0", before, len(df), "库存调整行、赠品行无商业销售额")

    # 4 非商品代码
    before = len(df)
    code = df["StockCode"].astype(str)
    is_product = code.str.match(PRODUCT_CODE) | code.str.startswith("DCGS")
    non_product = df.loc[~is_product]
    non_product_codes = sorted(non_product["StockCode"].unique().tolist())
    df = df.loc[is_product].copy()
    step("剔除非商品类代码", before, len(df),
         "邮费/人工/手续费/礼品券等：" + "、".join(map(str, non_product_codes[:12])) + " 等")

    # 5 价格异常复核（原始数据中单价 ≥1000 的行均属于非商品代码，已在第 4 步剔除）
    before = len(df)
    df = df.loc[df["UnitPrice"] < 1000].copy()
    step("极端价格复核（单价≥1000）", before, len(df),
         "复核后无新增剔除；极端价格行均为非商品代码，已在前一步处理")

    # 6 描述缺失回填
    before = len(df)
    desc_mode = df.dropna(subset=["Description"]).groupby("StockCode")["Description"].agg(
        lambda s: s.mode().iloc[0] if not s.mode().empty else None)
    df["Description"] = df["Description"].fillna(df["StockCode"].map(desc_mode))
    df = df.dropna(subset=["Description"]).copy()
    step("商品描述缺失回填/剔除", before, len(df), "按 StockCode 众数回填，仍缺失则剔除")

    # 7 指标派生
    df["Quantity"] = df["Quantity"].astype("int64")
    df["UnitPrice"] = df["UnitPrice"].astype(float)
    df["CustomerID"] = df["CustomerID"].astype("Int64")
    df["Revenue"] = (df["Quantity"] * df["UnitPrice"]).round(2)
    df["Year"] = df["InvoiceDate"].dt.year
    df["Month"] = df["InvoiceDate"].dt.month
    df["YearMonth"] = df["InvoiceDate"].dt.strftime("%Y-%m")
    df["Weekday"] = df["InvoiceDate"].dt.day_of_week      # 0=周一
    df["Hour"] = df["InvoiceDate"].dt.hour
    df["InvoiceDay"] = df["InvoiceDate"].dt.normalize()
    df["IsBulkOrder"] = (df["Quantity"] > 10000).astype(int)  # 标记而非剔除，保留真实批发业务

    # 8 分析窗口
    window = (df["InvoiceDate"] >= pd.Timestamp(WINDOW_START)) & \
             (df["InvoiceDate"] <= pd.Timestamp(WINDOW_END) + pd.Timedelta(days=1))
    df["InAnalysisWindow"] = window.astype(int)
    print(f"[clean] 分析窗口内记录：{int(window.sum()):,} 行（2011-12 部分月份仅 9 天，不参与趋势与建模）")

    # 9 落盘
    cols = ["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
            "UnitPrice", "CustomerID", "Country", "Revenue", "Year", "Month",
            "YearMonth", "Weekday", "Hour", "InvoiceDay", "IsBulkOrder", "InAnalysisWindow"]
    df = df[cols]
    df.to_csv(ALL_CSV, index=False, encoding="utf-8-sig")
    df[df["CustomerID"].notna()].to_csv(CUST_CSV, index=False, encoding="utf-8-sig")

    with sqlite3.connect(DB_PATH) as conn:
        df.to_sql("transactions_all", conn, if_exists="replace", index=False)
        df[df["CustomerID"].notna()].to_sql("transactions_customer", conn, if_exists="replace", index=False)
        returns.to_sql("returns", conn, if_exists="replace", index=False)

    # 质量报告
    sales = df[df["InAnalysisWindow"] == 1]
    report = {
        "raw_rows": n0,
        "clean_rows": int(len(df)),
        "analysis_window_rows": int(len(sales)),
        "retention_rate_%": round(len(df) / n0 * 100, 2),
        "returns_rows": int(len(returns)),
        "returns_invoices": int(returns["InvoiceNo"].nunique()),
        "sales_invoices": int(sales["InvoiceNo"].nunique()),
        "return_invoice_rate_%": round(returns["InvoiceNo"].nunique() /
                                       (returns["InvoiceNo"].nunique() + sales["InvoiceNo"].nunique()) * 100, 2),
        "customers": int(sales["CustomerID"].nunique()),
        "products": int(sales["StockCode"].nunique()),
        "countries": int(sales["Country"].nunique()),
        "total_revenue": round(float(sales["Revenue"].sum()), 2),
        "avg_order_value": round(float(sales.groupby("InvoiceNo")["Revenue"].sum().mean()), 2),
        "missing_after_clean": {k: int(v) for k, v in df.isna().sum().items()},
        "steps": log,
    }
    save_json(report, "cleaning_log.json")

    # 清洗前后关键指标表（论文用）
    kpi = pd.DataFrame([
        {"指标": "原始记录数", "数值": n0},
        {"指标": "清洗后记录数", "数值": len(df)},
        {"指标": "数据保留率(%)", "数值": round(len(df) / n0 * 100, 2)},
        {"指标": "退货单行数", "数值": len(returns)},
        {"指标": "分析窗口销售额(£)", "数值": round(float(sales["Revenue"].sum()), 2)},
        {"指标": "有效客户数", "数值": int(sales["CustomerID"].nunique())},
        {"指标": "有效商品数", "数值": int(sales["StockCode"].nunique())},
        {"指标": "覆盖国家数", "数值": int(sales["Country"].nunique())},
        {"指标": "平均客单价(£)", "数值": round(float(sales.groupby("InvoiceNo")["Revenue"].sum().mean()), 2)},
    ])
    save_table(kpi, "table01_kpi_overview.csv")
    print(f"[clean] 完成：{len(df):,} 行，销售额 £{sales['Revenue'].sum():,.0f}，"
          f"客户 {sales['CustomerID'].nunique():,}，商品 {sales['StockCode'].nunique():,}")


if __name__ == "__main__":
    main()
