# Online Retail 商业数据分析项目

> 《商业数据分析》期末大作业 · 2026 年秋季学期
> 选题：**英国礼品电商客户价值分层与销售预测——基于 UCI Online Retail 的全流程分析**

基于 UCI Machine Learning Repository 官方公开数据集 **Online Retail**（ID 352），完成从
数据合规获取、清洗治理、多模型分析、可视化复现到交互式大屏与论文写作的端到端流程。
全部代码使用 Python 实现，**未使用 Power BI / Tableau / Excel 图表截图**。

---

## 1. 核心结论速览（分析窗口 2010-12-01 ~ 2011-11-30）

| 指标 | 数值 | 说明 |
|---|---|---|
| 清洗后有效记录 | 522,537 行 | 窗口内 497,784 行 |
| 销售额 | £9,632,728 | 12 个月累计 |
| 有效订单（发票） | 18,957 张 | 不含退货单 |
| 有 ID 客户 | 4,293 人 | 复购率 63.87% |
| 商品 / 国家 | 3,904 / 38 | — |
| 客单价 | £508.14 | 销售额 / 发票数 |
| 英国收入占比 | 84.64% | 高度依赖本土市场 |
| 重要价值客户 | 1,398 人（32.56%） | 贡献 75.42% 销售额 |
| 商品帕累托 | 866 个商品（20.92%） | 贡献 80% 销售额 |
| 关联规则 | 48 条强规则 | 最强 lift = 24.06 |
| SARIMA 回测 | MAPE 24.43% / RMSE £18,690.79 | 季节朴素基线 MAPE 21.07% |

---

## 2. 数据来源与合规

- **数据集**：Online Retail（541,909 行 × 8 列，2010-12-01 ~ 2011-12-09，英国在线礼品零售商）
- **官方页面**：<https://archive.ics.uci.edu/dataset/352/online+retail>
- **下载地址**：<https://archive.ics.uci.edu/static/public/352/online+retail.zip>
- **获取方式**：官方一次性 ZIP 下载（**白名单第 1 类方式**），未使用任何爬虫、代理或网页抓取；
  下载逻辑固化在 [scripts/01_load.py](scripts/01_load.py)，可重复执行。
- **许可协议**：CC BY 4.0（允许教学、研究与二次分析，需注明来源）
- **获取日期**：2026-10-29
- **抽样说明**：主表**全量使用，未抽样**；仅可视化散点抽样 1,500 条，随机种子 `RANDOM_SEED = 42`。

> 为控制压缩包体积，本提交包未包含 `data/raw` 原始文件、`data/clean` 大体积明细与
> `retail.db`。原始数据运行 `python scripts/01_load.py` 可自动从官网重新下载；
> 清洗结果运行 `python scripts/02_clean.py` 可完整重建（详见 `data/README.md`）。

---

## 3. 目录结构

```
online-retail-analysis/
├── data/
│   ├── raw/                     # 官方原始文件（xlsx / zip / 原始 CSV，可用 01_load.py 重建）
│   ├── clean/                   # 清洗后数据（CSV + SQLite，可用 02_clean.py 重建）
│   └── README.md                # 字段字典与表结构说明
├── scripts/
│   ├── common.py                # 路径、字体、配色、保存函数等公共配置
│   ├── 01_load.py               # 合规下载 + 原始数据落地 + 概览 JSON
│   ├── 02_clean.py              # 去重/退货/异常/缺失处理 + 派生指标 + SQLite
│   ├── 03_analysis.py           # 7 类商业模型 + 15 张结果表
│   ├── 04_visuals.py            # fig01–fig20 图表 + figure_index.json
│   └── 05_dashboard.py          # 交互式大屏 outputs/dashboard.html
├── outputs/
│   ├── figures/                 # fig01–fig21（200 dpi PNG，中文标注）
│   ├── tables/                  # table01–table15、各 JSON 指标
│   ├── assets/echarts.min.js    # 大屏离线渲染库
│   └── dashboard.html           # 自包含交互大屏（断网可用）
├── docs/
│   ├── 数据来源合规声明.md
│   └── 期末论文.docx            # 论文终稿（≥3000 字）
├── run_all.py                   # 一键复现全流程
├── requirements.txt
└── README.md
```

---

## 4. 环境与一键复现

**环境**：Python 3.11+（开发验收环境 Python 3.13.14 / Windows 11）；依赖见 requirements.txt。

```bash
# 1) 安装依赖（国内网络建议加镜像）
pip install -r requirements.txt
# 如需镜像：pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple --trusted-host mirrors.aliyun.com

# 2) 一键复现（首次运行会从官方地址下载 ZIP，需联网）
python run_all.py

# 3) 仅重跑部分步骤（数据已就绪时可省略下载与清洗）
python run_all.py --from 3

# 4) 查看交互大屏
python -m http.server 8765
# 然后访问 http://localhost:8765/outputs/dashboard.html
```

也可以按顺序单独执行：

```bash
python scripts/01_load.py       # 下载并落地原始数据
python scripts/02_clean.py      # 清洗 + SQLite
python scripts/03_analysis.py   # 模型计算
python scripts/04_visuals.py    # 生成 20 张图
python scripts/05_dashboard.py  # 生成大屏
```

> 中文显示依赖系统字体 **Microsoft YaHei（微软雅黑）**，macOS/Linux 可在
> [scripts/common.py](scripts/common.py) 中把 `plt.rcParams["font.sans-serif"]` 改为
> `PingFang SC` / `Noto Sans CJK SC`。

---

## 5. 分析流程与产出

| 步骤 | 脚本 | 主要产出 |
|---|---|---|
| 获取 | `01_load.py` | `raw_data_profile.json`（行数、缺失、重复、退货等画像） |
| 清洗 | `02_clean.py` | `cleaning_log.json`（6 步清洗漏斗）、`table01_kpi_overview.csv`、CSV + SQLite |
| 建模 | `03_analysis.py` | `table02–table15`、`analysis_summary.json`、`forecast_metrics.json` |
| 可视化 | `04_visuals.py` | `fig01–fig20`（PNG）、`figure_index.json` |
| 大屏 | `05_dashboard.py` | `dashboard.html`（9 个组件、地区联动、月份下钻） |

### 5.1 清洗漏斗（541,909 → 522,537，保留率 96.43%）

| 步骤 | 剔除行数 | 依据 |
|---|---|---|
| 完全重复行去重 | 5,268 | 同一发票同商品同价格重复录入 |
| 退货/取消单归档 | 9,251 | `InvoiceNo` 以 C 开头，不计销售额（单独存 `returns.csv`） |
| 数量≤0 或单价≤0 | 2,512 | 库存调整、赠品行无商业销售额 |
| 非商品类代码 | 2,341 | AMAZONFEE / POST / M / DOT / gift_0001_* 等 |
| 极端价格复核 | 0 | 复核后无新增剔除 |
| 描述缺失回填 | 0 | 按 StockCode 众数回填 |

### 5.2 商业模型（7 类，均输出结果表 + 图表 + 结论）

1. **RFM 八分类**（分位数 1–5 评分 + 中位数二分）→ `table05/06/07`、fig11/fig12/fig05
2. **同期群留存**（首购月份分群、30 天滚动窗口）→ `table08/09`、fig13
3. **帕累托 / ABC**（商品收入累计 80% 分界）→ `table04`、fig14
4. **波士顿矩阵**（上半年月均 vs 下半年月均 + 收入份额）→ `table10`、fig18
5. **客户忠诚度漏斗**（订单数分层）+ 30/90/180 日复购速度 → `table11`、fig16
6. **关联规则 Apriori**（top200 商品、min_support=2%、lift≥1.2）→ `table12`、fig19
7. **SARIMA 日销售额预测**（回测 28 天、95% 置信区间）→ `table13/14`、fig17

---

## 6. 图表索引（fig01–fig21）

| 编号 | 文件 | 类别 | 内容 |
|---|---|---|---|
| fig01 | fig01_月度销售额趋势.png | 模板复现 | 月度销售额 + 3 月移动平均 |
| fig02 | fig02_月度订单量与客单价.png | 模板复现 | 订单量柱 + 客单价折线（双轴） |
| fig03 | fig03_国家销售额Top10.png | 模板复现 | 国家销售条形榜（英国以外） |
| fig04 | fig04_国家销售额结构.png | 模板复现 | 国家结构环形图 |
| fig05 | fig05_客户群月度销售额构成.png | 模板复现 | RFM 客群月度堆积面积 |
| fig06 | fig06_月度销售额玫瑰图.png | 模板复现 | 月度销售额南丁格尔玫瑰 |
| fig07 | fig07_订单金额分布箱线图.png | 模板复现 | 主要国家订单金额箱线（log） |
| fig08 | fig08_商品销售额树状图.png | 模板复现 | 商品销售额树状图 |
| fig09 | fig09_时段星期热力图.png | 模板复现 | 下单时段 × 星期热力 |
| fig10 | fig10_购买频次与客单价散点.png | 模板复现 | 频次 × 客单价散点 |
| fig11 | fig11_RFM客户群雷达图.png | 业务模型 | 八群 R/F/M 均值雷达 |
| fig12 | fig12_RFM客户价值气泡图.png | 业务模型 | 客户价值气泡（F × M） |
| fig13 | fig13_同期群留存热力图.png | 业务模型 | 同期群留存矩阵 |
| fig14 | fig14_商品帕累托图.png | 业务模型 | 帕累托曲线 + ABC 分层 |
| fig15 | fig15_月度环比瀑布图.png | 模板复现 | 月度环比变化瀑布 |
| fig16 | fig16_复购漏斗图.png | 业务模型 | 客户忠诚度漏斗 |
| fig17 | fig17_SARIMA预测图.png | 业务模型 | 日销售额预测 + 95% CI |
| fig18 | fig18_波士顿矩阵.png | 业务模型 | 商品四象限矩阵 |
| fig19 | fig19_关联规则散点图.png | 业务模型 | 支持度 × 置信度（lift 气泡） |
| fig20 | fig20_KPI指标卡.png | 模板复现 | 6 项核心 KPI 指标卡 |
| fig21 | fig21_交互大屏截图.png | 大屏 | 交互式大屏全屏截图 |

> 模板复现 12 张（fig01–fig10 及 fig15 / fig20），业务模型图 8 张（fig11–fig14、fig16–fig19），
> 另有大屏截图 1 张，合计 21 张。全部由 matplotlib / pyecharts 生成，分辨率 ≥200 dpi。

---

## 7. 交互式大屏（outputs/dashboard.html）

- **技术栈**：Pyecharts 2.1.0（ECharts 5 内核），ECharts 库已内联，**离线可打开**。
- **组件（9 个）**：6 张 KPI 指标卡、月度销售额与订单量（柱线双轴）、国家 TOP10、
  商品 TOP10、RFM 八群玫瑰图、客户频次 × 金额散点（双对数）、时段 × 星期热力图、
  高价值客户 TOP10 明细表、月度商品 TOP5 时间轴。
- **联动 / 交互**：顶部「地区筛选」下拉（全部 / 英国 / 海外）联动 KPI、趋势图、商品榜；
  时间轴自动播放并可按月下钻当年 TOP5 商品；全部图表支持悬停提示、图例开关，趋势图带 DataZoom。
- **验收记录**：浏览器实测 7 个 ECharts 容器全部渲染，控制台无报错；切换地区后 KPI 由
  £9.63M 变为 £8.15M。

---

## 8. 质量与可复现性

- 随机种子 `RANDOM_SEED = 42`（`scripts/common.py`），所有抽样可复现；
- 图表统一 `figNN_xxx.png` 命名，索引见 `outputs/tables/figure_index.json`；
- 图表统一 200 dpi、中文字体、金额单位 £、坐标轴与图例规范；
- 每一步均落盘中间结果，可从任意步骤续跑（`python run_all.py --from N`）；
- 数据可复用格式：CSV（UTF-8-SIG）、JSON（指标与日志）、SQLite（`data/clean/retail.db`）。

---

## 9. 说明

- 本仓库为课程作业用途，数据集版权归原作者及 UCI 所有，遵循 CC BY 4.0；
- 论文与代码中涉及的结论均基于 2010-12 ~ 2011-11 的英国礼品批发/零售场景，结论外推需谨慎。
