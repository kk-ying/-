"""03_analysis.py —— 商业分析模型计算

包含 6 个模型（超过课程要求的 3 个）：
1) RFM 八分类客户价值模型（R/F/M 中位数切分，附 1-5 分位评分）；
2) 同期群（Cohort）留存分析；
3) 帕累托 / ABC 商品分类；
4) 波士顿矩阵（收入份额 × 收入增速，气泡大小=收入）；
5) 复购漏斗转化分析；
6) 关联规则 Apriori（mlxtend）；
7) SARIMA 日销售额预测（含 95% 置信区间与回测 MAPE/RMSE）；
另附环比（MoM）与移动平均等趋势指标。

所有结果输出至 outputs/tables/，供 04_visuals.py 与论文引用。
"""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder
from statsmodels.tsa.statespace.sarimax import SARIMAX

from common import ALL_CSV, CUST_CSV, WINDOW_END, WINDOW_START, save_json, save_table

warnings.filterwarnings("ignore")
SNAPSHOT = pd.Timestamp(WINDOW_END)  # RFM 观察截止日：2011-11-30
SEG_ORDER = ["重要价值客户", "重要保持客户", "重要发展客户", "重要挽留客户",
             "一般价值客户", "一般保持客户", "一般发展客户", "一般挽留客户"]


def load() -> pd.DataFrame:
    df = pd.read_csv(ALL_CSV, dtype={"InvoiceNo": str, "StockCode": str},
                     parse_dates=["InvoiceDate", "InvoiceDay"])
    df = df[df["InAnalysisWindow"] == 1].copy()
    df["CustomerID"] = df["CustomerID"].astype("Int64")
    return df


# ------------------------------------------------------------------ 趋势
def trend(df: pd.DataFrame) -> pd.DataFrame:
    m = df.groupby("YearMonth").agg(
        revenue=("Revenue", "sum"),
        orders=("InvoiceNo", "nunique"),
        customers=("CustomerID", "nunique"),
        items=("Quantity", "sum"),
    ).reset_index()
    m["aov"] = (m["revenue"] / m["orders"]).round(2)
    m["mom_rate"] = (m["revenue"].pct_change() * 100).round(2)
    m["ma3"] = m["revenue"].rolling(3, min_periods=2).mean().round(2)
    save_table(m, "table02_monthly_sales.csv")
    print(f"[model] 月度销售额：峰值 {m.loc[m.revenue.idxmax(), 'YearMonth']}"
          f"（£{m.revenue.max():,.0f}），谷值 {m.loc[m.revenue.idxmin(), 'YearMonth']}")
    return m


def country(df: pd.DataFrame) -> pd.DataFrame:
    c = df.groupby("Country").agg(
        revenue=("Revenue", "sum"),
        orders=("InvoiceNo", "nunique"),
        customers=("CustomerID", "nunique"),
    ).sort_values("revenue", ascending=False).reset_index()
    c["share"] = (c["revenue"] / c["revenue"].sum() * 100).round(2)
    c["cum_share"] = c["share"].cumsum().round(2)
    save_table(c, "table03_country_sales.csv")
    return c


def product(df: pd.DataFrame) -> pd.DataFrame:
    p = df.groupby(["StockCode", "Description"]).agg(
        revenue=("Revenue", "sum"),
        quantity=("Quantity", "sum"),
        orders=("InvoiceNo", "nunique"),
    ).sort_values("revenue", ascending=False).reset_index()
    p["share"] = (p["revenue"] / p["revenue"].sum() * 100).round(2)
    p["cum_share"] = p["share"].cumsum().round(2)
    p["abc_class"] = np.where(p["cum_share"] <= 80, "A",
                              np.where(p["cum_share"] <= 95, "B", "C"))
    save_table(p, "table04_product_sales.csv")
    return p


# ------------------------------------------------------------------ RFM
def rfm(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    cust = df.dropna(subset=["CustomerID"]).copy()
    g = cust.groupby("CustomerID").agg(
        last_purchase=("InvoiceDay", "max"),
        first_purchase=("InvoiceDay", "min"),
        frequency=("InvoiceNo", "nunique"),
        monetary=("Revenue", "sum"),
    )
    g["recency"] = (SNAPSHOT - g["last_purchase"]).dt.days
    g["monetary"] = g["monetary"].round(2)

    # 1-5 分位评分：R 越小越好；使用 rank 避免重复分位边界
    g["R_score"] = pd.qcut(g["recency"].rank(method="first"), 5, labels=[5, 4, 3, 2, 1]).astype(int)
    g["F_score"] = pd.qcut(g["frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
    g["M_score"] = pd.qcut(g["monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)

    # 八分类：以中位数为阈值切分（对偏态分布稳健，且保证八类样本量均衡）
    r_med, f_med, m_med = g["recency"].median(), g["frequency"].median(), g["monetary"].median()
    r_high = g["recency"] <= r_med
    f_high = g["frequency"] >= f_med
    m_high = g["monetary"] >= m_med

    def segment(i: int) -> str:
        rh, fh, mh = r_high.iat[i], f_high.iat[i], m_high.iat[i]
        if rh and fh and mh:
            return "重要价值客户"
        if not rh and fh and mh:
            return "重要保持客户"
        if rh and not fh and mh:
            return "重要发展客户"
        if not rh and not fh and mh:
            return "重要挽留客户"
        if rh and fh and not mh:
            return "一般价值客户"
        if not rh and fh and not mh:
            return "一般保持客户"
        if rh and not fh and not mh:
            return "一般发展客户"
        return "一般挽留客户"

    g["segment"] = [segment(i) for i in range(len(g))]
    g["rfm_score"] = g["R_score"] + g["F_score"] + g["M_score"]
    g = g.reset_index()
    g["CustomerID"] = g["CustomerID"].astype("Int64")
    save_table(g, "table05_rfm_customers.csv")

    seg = g.groupby("segment").agg(
        customers=("CustomerID", "count"),
        revenue=("monetary", "sum"),
        avg_recency=("recency", "mean"),
        avg_frequency=("frequency", "mean"),
        avg_monetary=("monetary", "mean"),
        avg_r_score=("R_score", "mean"),
        avg_f_score=("F_score", "mean"),
        avg_m_score=("M_score", "mean"),
    ).round(2).reindex(SEG_ORDER).reset_index()
    seg["customer_share"] = (seg["customers"] / seg["customers"].sum() * 100).round(2)
    seg["revenue_share"] = (seg["revenue"] / seg["revenue"].sum() * 100).round(2)
    save_table(seg, "table06_rfm_segments.csv")

    # 八群 × 月度销售额（堆积面积图数据）
    cust["segment"] = cust["CustomerID"].map(g.set_index("CustomerID")["segment"])
    sm = cust.groupby(["YearMonth", "segment"])["Revenue"].sum().reset_index()
    save_table(sm, "table07_segment_monthly.csv")

    print(f"[model] RFM：{len(g):,} 位客户，中位数阈值 R≤{r_med:.0f}天 / F≥{f_med:.0f}次 / M≥£{m_med:,.0f}")
    print(seg[["segment", "customers", "customer_share", "revenue_share", "avg_monetary"]].to_string(index=False))
    return g, seg


# ------------------------------------------------------------------ Cohort
def cohort(df: pd.DataFrame) -> pd.DataFrame:
    """同期群留存：按首购月份分群，以「自首购起的 30 天窗口」计算留存。

    采用 30 天滚动窗口而非自然月，可消除“月末首购客户在首月只剩几天”的
    截断偏差，使留存曲线在业务上可比。
    """
    cust = df.dropna(subset=["CustomerID"]).copy()
    first = cust.groupby("CustomerID")["InvoiceDay"].min().rename("first_day")
    cust = cust.merge(first, left_on="CustomerID", right_index=True)
    cust["cohort"] = cust["first_day"].dt.strftime("%Y-%m")
    cust["offset"] = ((cust["InvoiceDay"] - cust["first_day"]).dt.days // 30).astype(int)

    active = cust[["cohort", "CustomerID", "offset"]].drop_duplicates()
    size = active[active["offset"] == 0].groupby("cohort")["CustomerID"].nunique()
    counts = active.groupby(["cohort", "offset"])["CustomerID"].nunique().unstack(fill_value=0)
    counts = counts.reindex(sorted(counts.index))

    # 掩码：仅保留已完整观察的 30 天窗口（避免近月 cohort 被低估）
    fd = cust.groupby("cohort")["first_day"].min()
    mask = pd.DataFrame(
        [[(fd[c] + pd.Timedelta(days=30 * (o + 1)) <= SNAPSHOT + pd.Timedelta(days=1)) or o == 0
          for o in counts.columns] for c in counts.index],
        index=counts.index, columns=counts.columns)

    retention = counts.div(size, axis=0).mul(100).round(2).where(mask)
    retention.insert(0, "cohort_size", size.reindex(retention.index).astype(int))
    save_table(retention.reset_index(), "table08_cohort_retention.csv")

    avg = retention.drop(columns=["cohort_size"]).mean().round(2)
    print("[model] 同期群留存（各窗口平均）：" +
          "，".join(f"M{int(k)} {v:.1f}%" for k, v in list(avg.items())[:6]))
    save_table(pd.DataFrame({"offset": avg.index.astype(int), "avg_retention": avg.values}),
               "table09_cohort_avg.csv")
    return retention


# ------------------------------------------------------------------ ABC / Pareto
def pareto(p: pd.DataFrame) -> dict:
    n = len(p)
    n80 = int((p["cum_share"] <= 80).sum())
    rev = float(p["revenue"].sum())
    top20_rev = float(p.head(int(round(n * 0.2)))["revenue"].sum())
    a_rev = float(p.loc[p["abc_class"] == "A", "revenue"].sum())
    stats = {
        "products": n,
        "products_to_80pct": n80,
        "products_to_80pct_ratio_%": round(n80 / n * 100, 2),
        "top20pct_products_revenue_share_%": round(top20_rev / rev * 100, 2),
        "class_A_products": int((p["abc_class"] == "A").sum()),
        "class_A_revenue_share_%": round(a_rev / rev * 100, 2),
        "top1_product": p.iloc[0]["Description"] if p.iloc[0]["Description"] else p.iloc[0]["StockCode"],
        "top1_revenue": round(float(p.iloc[0]["revenue"]), 2),
    }
    print(f"[model] 帕累托：{stats['products_to_80pct']} 个商品（{stats['products_to_80pct_ratio_%']}%）"
          f"贡献 80% 销售额；A 类商品 {stats['class_A_products']} 个贡献 {stats['class_A_revenue_share_%']}%")
    return stats


# ------------------------------------------------------------------ 波士顿矩阵
def boston(df: pd.DataFrame) -> pd.DataFrame:
    h1 = df[df["YearMonth"] <= "2011-06"].groupby(["StockCode", "Description"])["Revenue"].sum() / 6
    h2 = df[df["YearMonth"] >= "2011-07"].groupby(["StockCode", "Description"])["Revenue"].sum() / 5
    total = df.groupby(["StockCode", "Description"])["Revenue"].sum()
    b = pd.DataFrame({"avg_h1": h1, "avg_h2": h2}).dropna()
    b = b[(b["avg_h1"] > 0) & (b["avg_h2"] > 0)]
    b["growth"] = (b["avg_h2"] - b["avg_h1"]) / b["avg_h1"] * 100
    b["revenue"] = total.reindex(b.index)
    b["share"] = b["revenue"] / total.sum() * 100
    b = b[b["revenue"] >= 3000].sort_values("revenue", ascending=False).head(30).reset_index()
    b["quadrant"] = np.select(
        [(b["share"] >= b["share"].median()) & (b["growth"] >= 0),
         (b["share"] < b["share"].median()) & (b["growth"] >= 0),
         (b["share"] >= b["share"].median()) & (b["growth"] < 0)],
        ["明星产品", "问题产品", "现金牛产品"], default="瘦狗产品")
    save_table(b.round(2), "table10_boston_matrix.csv")
    print(f"[model] 波士顿矩阵：{len(b)} 个重点商品，四象限分布 "
          f"{b['quadrant'].value_counts().to_dict()}")
    return b


# ------------------------------------------------------------------ 漏斗
def funnel(df: pd.DataFrame) -> pd.DataFrame:
    """客户忠诚度漏斗：按累计订单数分层，各层严格嵌套、转化率单调递减。

    另外计算首购后 30/90/180 日复购率，用于刻画复购速度（见 summary）。
    """
    cust = df.dropna(subset=["CustomerID"]).copy()
    orders = cust.groupby("CustomerID")["InvoiceNo"].nunique()
    n0 = len(orders)
    stages = [
        ("全部客户", n0),
        ("复购客户（≥2 单）", int((orders >= 2).sum())),
        ("活跃客户（≥5 单）", int((orders >= 5).sum())),
        ("忠诚客户（≥10 单）", int((orders >= 10).sum())),
        ("核心客户（≥20 单）", int((orders >= 20).sum())),
    ]
    rows = []
    for i, (stage, cnt) in enumerate(stages):
        prev = stages[i - 1][1] if i else cnt
        rows.append({
            "stage": stage,
            "customers": cnt,
            "conversion_rate": round(cnt / n0 * 100, 2),          # 占全部客户
            "stage_conversion": round(cnt / prev * 100, 2),        # 相邻层转化
        })
    f = pd.DataFrame(rows)
    save_table(f, "table11_repurchase_funnel.csv")

    # 首购后复购速度（累计口径）
    dates = cust[["CustomerID", "InvoiceDay"]].drop_duplicates().sort_values(["CustomerID", "InvoiceDay"])
    dates["rank"] = dates.groupby("CustomerID").cumcount()
    first = dates[dates["rank"] == 0].set_index("CustomerID")["InvoiceDay"]
    second = dates[dates["rank"] == 1].set_index("CustomerID")["InvoiceDay"]
    base = first[first <= pd.Timestamp("2011-02-28")].index
    gap = (second.reindex(base) - first.reindex(base)).dt.days.dropna()
    speed = {
        "base_customers": int(len(base)),
        "repurchase_within_30d_%": round(float((gap <= 30).sum() / len(base) * 100), 2),
        "repurchase_within_90d_%": round(float((gap <= 90).sum() / len(base) * 100), 2),
        "repurchase_within_180d_%": round(float((gap <= 180).sum() / len(base) * 100), 2),
    }
    f.attrs["speed"] = speed
    print(f"[model] 忠诚度漏斗：全部 {n0:,} → 复购 {(orders >= 2).sum():,} → "
          f"≥5 单 {(orders >= 5).sum():,} → ≥10 单 {(orders >= 10).sum():,}；"
          f"30 日复购率 {speed['repurchase_within_30d_%']}%")
    return f


# ------------------------------------------------------------------ 关联规则
def basket_rules(df: pd.DataFrame, max_items: int = 200) -> pd.DataFrame:
    b = df.dropna(subset=["CustomerID"])[["InvoiceNo", "StockCode", "Description"]].drop_duplicates()
    top_codes = b.groupby("StockCode")["InvoiceNo"].nunique().sort_values(ascending=False).head(max_items).index
    b = b[b["StockCode"].isin(top_codes)].copy()
    b["item"] = b["Description"].str.strip().str.title().str[:32]
    b = b.drop_duplicates(["InvoiceNo", "item"])
    sizes = b.groupby("InvoiceNo")["item"].size()
    b = b[b["InvoiceNo"].isin(sizes[sizes >= 2].index)]

    basket = b.groupby(["InvoiceNo", "item"]).size().unstack(fill_value=0).astype(bool)
    freq = apriori(basket, min_support=0.02, use_colnames=True, max_len=2)
    rules = association_rules(freq, metric="lift", min_threshold=1.2)
    rules = rules[(rules["confidence"] >= 0.5) & (rules["lift"] >= 1.2)].copy()
    rules["antecedents"] = rules["antecedents"].apply(lambda s: " + ".join(sorted(s)))
    rules["consequents"] = rules["consequents"].apply(lambda s: " + ".join(sorted(s)))
    rules = rules.sort_values("lift", ascending=False)
    out = rules[["antecedents", "consequents", "support", "confidence", "lift"]].round(4)
    save_table(out, "table12_association_rules.csv")
    print(f"[model] 关联规则：{len(basket):,} 张多品发票，{len(out)} 条强规则（support≥2%，conf≥50%，lift≥1.2）")
    if len(out):
        print("        最强规则：" + out.iloc[0]["antecedents"] + " → " + out.iloc[0]["consequents"]
              + f"（lift={out.iloc[0]['lift']:.2f}）")
    return out


# ------------------------------------------------------------------ SARIMA
def sarima(df: pd.DataFrame, horizon: int = 28) -> tuple[pd.DataFrame, dict]:
    daily = (df.groupby("InvoiceDay")["Revenue"].sum()
             .reindex(pd.date_range(WINDOW_START, WINDOW_END, freq="D"), fill_value=0.0))
    daily.index.freq = "D"
    train, test = daily.iloc[:-horizon], daily.iloc[-horizon:]

    def fit(series):
        # 季节阶数经 4 组候选配置回测比较后选定：(1,1,0,7) 的 MAPE 与 RMSE 均最优
        return SARIMAX(series, order=(1, 1, 1), seasonal_order=(1, 1, 0, 7),
                       enforce_stationarity=False, enforce_invertibility=False).fit(disp=False)

    # 回测：用前 337 天预测最后 28 天
    res_bt = fit(train)
    fc_bt = res_bt.get_forecast(steps=horizon)
    # 销售额非负：点预测与区间下界截断至 0，避免出现负销售额的无意义区间
    pred = fc_bt.predicted_mean.clip(lower=0)
    ci = fc_bt.conf_int(alpha=0.05).clip(lower=0)
    mape = float(np.mean(np.abs((test - pred) / test.replace(0, np.nan))).item() * 100)
    rmse = float(np.sqrt(np.mean((test - pred) ** 2)))
    naive = test.shift(7).bfill()
    mape_naive = float(np.mean(np.abs((test - naive) / test.replace(0, np.nan))).item() * 100)

    # 全量重估，预测未来 28 天（2011-12）
    res_full = fit(daily)
    fc = res_full.get_forecast(steps=horizon)
    future_idx = pd.date_range(daily.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    fci = fc.conf_int(alpha=0.05).clip(lower=0)
    out = pd.DataFrame({
        "date": future_idx,
        "forecast": fc.predicted_mean.clip(lower=0).values.round(2),
        "lower_95": fci.iloc[:, 0].values.round(2),
        "upper_95": fci.iloc[:, 1].values.round(2),
        "type": "forecast",
    })
    bt = pd.DataFrame({
        "date": test.index,
        "forecast": pred.values.round(2),
        "lower_95": ci.iloc[:, 0].values.round(2),
        "upper_95": ci.iloc[:, 1].values.round(2),
        "actual": test.values.round(2),
        "type": "backtest",
    })
    save_table(pd.concat([bt, out], ignore_index=True), "table13_sarima_forecast.csv")
    metrics = {
        "model": "SARIMA(1,1,1)(1,1,0,7)",
        "train_days": int(len(train)),
        "test_days": int(horizon),
        "backtest_MAPE_%": round(mape, 2),
        "backtest_RMSE": round(rmse, 2),
        "seasonal_naive_MAPE_%": round(mape_naive, 2),
        "forecast_next_28d_total": round(float(out["forecast"].sum()), 2),
        "forecast_lower_total": round(float(out["lower_95"].sum()), 2),
        "forecast_upper_total": round(float(out["upper_95"].sum()), 2),
        "ci_note": "日度 95% 区间（下界截断为 0）；累计区间为日区间上下限之和，属近似处理",
        "aic": round(float(res_full.aic), 2),
    }
    save_json(metrics, "forecast_metrics.json")
    save_table(pd.DataFrame([metrics]), "table14_forecast_metrics.csv")
    print(f"[model] SARIMA：回测 MAPE {mape:.2f}%（季节朴素基线 {mape_naive:.2f}%），"
          f"RMSE £{rmse:,.0f}；未来 28 天预测 £{out['forecast'].sum():,.0f}")
    return out, metrics


def main() -> None:
    df = load()
    m = trend(df)
    c = country(df)
    p = product(df)
    customers, seg = rfm(df)
    retention = cohort(df)
    pstats = pareto(p)
    b = boston(df)
    f = funnel(df)
    rules = basket_rules(df)
    forecast, fmetrics = sarima(df)

    # 时段 × 星期 热力图数据
    hw = (df.pivot_table(index="Hour", columns="Weekday", values="Revenue",
                         aggfunc="sum", fill_value=0).reindex(index=range(6, 21), columns=range(7),
                                                             fill_value=0))
    hw.columns = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    save_table(hw.reset_index(), "table15_hour_weekday.csv")

    # ---------------- 论文引用汇总
    cust = df.dropna(subset=["CustomerID"])
    invoice_rev = df.groupby("InvoiceNo")["Revenue"].sum()
    n_cust = cust["CustomerID"].nunique()
    repeat_rate = (cust.groupby("CustomerID")["InvoiceNo"].nunique() > 1).mean() * 100
    top20_cust = cust.groupby("CustomerID")["Revenue"].sum().sort_values(ascending=False)
    top20_share = top20_cust.head(int(round(n_cust * 0.2))).sum() / top20_cust.sum() * 100
    uk_share = float(c.loc[c.Country == "United Kingdom", "share"].iloc[0])
    peak = m.loc[m["revenue"].idxmax()]
    low = m.loc[m["revenue"].idxmin()]
    seg_map = seg.set_index("segment")
    summary = {
        "analysis_window": f"{WINDOW_START} ~ {WINDOW_END}",
        "revenue": round(float(df["Revenue"].sum()), 2),
        "orders": int(df["InvoiceNo"].nunique()),
        "customers": int(n_cust),
        "products": int(df["StockCode"].nunique()),
        "countries": int(df["Country"].nunique()),
        # 客单价口径统一为「窗口内销售额 / 有效发票数」，与月度表、大屏保持一致
        "avg_order_value": round(float(df["Revenue"].sum() / df["InvoiceNo"].nunique()), 2),
        "median_order_value": round(float(invoice_rev.median()), 2),
        "repeat_purchase_rate_%": round(float(repeat_rate), 2),
        "uk_revenue_share_%": round(uk_share, 2),
        "peak_month": str(peak["YearMonth"]),
        "peak_month_revenue": round(float(peak["revenue"]), 2),
        "low_month": str(low["YearMonth"]),
        "low_month_revenue": round(float(low["revenue"]), 2),
        "top20pct_customers_revenue_share_%": round(float(top20_share), 2),
        "pareto": pstats,
        "rfm_segments": seg.set_index("segment")[
            ["customers", "customer_share", "revenue_share", "avg_monetary"]].round(2).to_dict("index"),
        "vip_segment_revenue_share_%": round(float(
            seg[seg.segment.isin(["重要价值客户", "重要保持客户"])]["revenue_share"].sum()), 2),
        "funnel": f.to_dict("records"),
        "repurchase_speed": f.attrs["speed"],
        "sarima": fmetrics,
        "rules_count": int(len(rules)),
        "top_rule": None if not len(rules) else {
            "antecedents": rules.iloc[0]["antecedents"],
            "consequents": rules.iloc[0]["consequents"],
            "support": float(rules.iloc[0]["support"]),
            "confidence": float(rules.iloc[0]["confidence"]),
            "lift": float(rules.iloc[0]["lift"]),
        },
        "boston": b["quadrant"].value_counts().to_dict(),
    }
    save_json(summary, "analysis_summary.json")
    print(f"[model] 汇总：销售额 £{summary['revenue']:,.0f}｜订单 {summary['orders']:,}｜"
          f"客户 {summary['customers']:,}｜客单价 £{summary['avg_order_value']:,.2f}｜"
          f"复购率 {summary['repeat_purchase_rate_%']}%")


if __name__ == "__main__":
    main()
